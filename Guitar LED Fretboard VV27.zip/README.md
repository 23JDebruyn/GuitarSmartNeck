
  # Guitar LED Fretboard

  This is a code bundle for Guitar LED Fretboard. The original project is available at https://www.figma.com/design/SCA1R1wbNd3LIWp7Huc2F9/Guitar-LED-Fretboard.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  
import { defineConfig } from 'vite'
import react from '@vitejs/plugin-react'
import path from 'path'

// Simple HTTP configuration for local development
// HTTPS can be enabled later if needed for microphone access on iPhone
export default defineConfig({
  plugins: [react()],
  // Set base to '/' for root deployment or '/repo-name/' for GitHub Pages
  // Change this to match your GitHub repository name if deploying to GitHub Pages
  base: process.env.GITHUB_ACTIONS ? '/GuitarSmartNeck/' : '/',
  resolve: {
    alias: {
      '@': path.resolve(__dirname, './src'),
    },
  },
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: false,
    allowedHosts: [
      '.loca.lt',
      '.ngrok.io',
      '.vercel.app',
    ],
  },
})

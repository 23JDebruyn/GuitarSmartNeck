# 🎨 Pattern Cycle Button Feature

## Overview

The GuitarSmartNeck now includes a **Pattern Cycle** button that triggers 6 different LED animations and page navigations. This feature is available both in the app (Home page) and on the ESP32 hardware (physical button).

---

## 📱 App Implementation (Home Page)

### Location
- **Home** tab in the top navigation bar
- Large "Pattern Cycle" button in the center of the screen

### Patterns
1. **Bar Fill** - Strings light up sequentially in white → red → blue → green, then clear
2. **Wave** - Wave animation sweeps across all frets
3. **Rainbow** - All LEDs on, each string in a different color (red, orange, yellow, green, blue, purple)
4. **Fret Indicators** - Navigates to Standard page showing fret markers
5. **Chords** - Navigates to Chord page
6. **Pentatonic** - Navigates to Pentatonic page

### Usage
1. Open the app and go to **Home** page
2. Connect to ESP32 via Settings
3. Click "Pattern Cycle" button
4. Each click advances to the next pattern

---

## 🔘 Hardware Implementation (ESP32)

### Button Wiring

**Simple 2-Wire Connection:**
```
Button Pin 1 ──────────> ESP32 GPIO 4
Button Pin 2 ──────────> ESP32 GND
```

**Features:**
- Uses internal pull-up resistor (no external resistor needed)
- Debounced in software (50ms debounce time)
- Press cycles through all 6 patterns

### Button Behavior
- **Patterns 1-3**: Execute LED animations on the fretboard
- **Patterns 4-6**: Flash white twice (since page navigation is app-only)

### Customization

You can change the button pin by editing this line in the Arduino sketch:

```cpp
#define BUTTON_PIN      4         // Change to your desired GPIO pin
```

You can adjust debounce sensitivity:

```cpp
#define BUTTON_DEBOUNCE 50        // Change milliseconds (increase if button is too sensitive)
```

---

## 🎯 Pattern Details

### Pattern 1: Bar Fill
- Each string lights up sequentially
- Repeats in 4 colors: white, red, blue, green
- Creates a "filling" effect across the fretboard
- Duration: ~6 seconds

### Pattern 2: Wave
- Wave of gradient colors sweeps left to right
- Colors transition from cyan to magenta
- Smooth animation across all frets
- Duration: ~2 seconds

### Pattern 3: Rainbow Strings
- String 0 (High E): Red
- String 1 (B): Orange
- String 2 (G): Yellow
- String 3 (D): Green
- String 4 (A): Blue
- String 5 (Low E): Purple
- Duration: 2 seconds

### Pattern 4-6: Page Navigation (App Only)
- In app: Navigates to respective pages
- On ESP32 hardware: Flashes white twice

---

## 🛠️ Technical Implementation

### App Side (React/TypeScript)
- Component: `/components/HomePage.tsx`
- Uses WebSocket/HTTP to send LED commands to ESP32
- Async pattern execution with cancellation support
- Navigation handled by parent App component

### ESP32 Side (Arduino C++)
- Functions: `pattern1BarFill()`, `pattern2Wave()`, `pattern3Rainbow()`
- Button handling: `handleButton()` with debouncing
- Executed in main loop: `loop()`
- Uses FastLED library for LED control

---

## 🔍 Troubleshooting

### App Issues

**Button is disabled:**
- Make sure ESP32 is connected (Settings page)
- Check WiFi connection to "GuitarSmartNeck" network

**Patterns don't play:**
- Verify ESP32 is powered on
- Check Serial Monitor for connection status
- Try disconnecting/reconnecting in Settings

### Hardware Issues

**Button doesn't respond:**
- Check wiring (GPIO 4 to GND)
- Open Serial Monitor (115200 baud)
- Press button and look for "Button pressed!" message
- Try different button (ensure it's momentary, not latching)

**Button too sensitive (multiple triggers):**
- Increase `BUTTON_DEBOUNCE` value (e.g., from 50 to 100)
- Check for loose wiring

**LEDs don't animate:**
- Verify LED strip is connected to GPIO 5
- Check power supply to LED strip
- Confirm FastLED library is installed

---

## 📝 Customization Ideas

### Add More Patterns
Edit ESP32 code and add new cases to `executePattern()`:

```cpp
case 6:
  myCustomPattern();
  break;
```

Update the pattern count:
```cpp
currentPattern = (currentPattern + 1) % 7;  // Changed from 6 to 7
```

### Change Pattern Timing
Adjust delay values in pattern functions:

```cpp
delay(150);  // Make this smaller for faster animation
```

### Change Colors
Modify color arrays in each pattern function:

```cpp
CRGB colors[] = {CRGB::White, CRGB::Red, CRGB::Blue, CRGB::Green};
// Change to your preferred colors
```

---

## 🎸 Use Cases

1. **Guitar Store Demo** - Attract customers with eye-catching patterns
2. **Teaching Tool** - Demonstrate fretboard coverage before lessons
3. **Performance** - Visual effects during live shows
4. **LED Testing** - Verify all LEDs are working correctly
5. **Party Mode** - Fun light show at gatherings

---

## 🔄 Pattern Cycle Flow

```
User presses button/clicks app button
    ↓
Pattern index increments (0 → 1 → 2 → 3 → 4 → 5 → 0...)
    ↓
Execute corresponding pattern
    ↓
[Pattern 1-3]: LED animation plays
[Pattern 4-6]: Navigate to page (app) or flash (ESP32)
    ↓
Ready for next button press
```

---

## 📚 Related Files

### App Files
- `/components/HomePage.tsx` - Home page with pattern button
- `/App.tsx` - Main app with navigation routing
- `/components/TopNav.tsx` - Top navigation bar
- `/components/WiFiContext.tsx` - ESP32 communication

### ESP32 Files
- `/ESP32_WiFi_Fretboard_LED.ino` - Main Arduino sketch with patterns

### Documentation
- `/README.md` - Main project documentation
- `/DEPLOY.md` - Deployment instructions

---

## 🎉 Enjoy!

The Pattern Cycle button adds a fun, interactive way to showcase your GuitarSmartNeck LED fretboard. Experiment with patterns, customize colors, and create your own animations!

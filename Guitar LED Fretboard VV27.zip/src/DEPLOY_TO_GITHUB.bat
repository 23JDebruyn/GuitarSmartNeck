@echo off
echo ========================================
echo GitHub Pages Deployment Helper
echo ========================================
echo.

echo This script will help you deploy to GitHub Pages
echo.

echo First, create a new repository on GitHub:
echo 1. Go to https://github.com/new
echo 2. Name it: GuitarSmartNeck (or your preferred name)
echo 3. Make it Public
echo 4. Don't initialize with README
echo 5. Click Create repository
echo.

pause

echo.
echo Enter your GitHub username:
set /p username=

echo.
echo Enter your repository name (e.g., GuitarSmartNeck):
set /p reponame=

echo.
echo Initializing git and pushing to GitHub...
echo.

git init
git add .
git commit -m "Initial commit - GuitarSmartNeck app"
git branch -M main
git remote add origin https://github.com/%username%/%reponame%.git
git push -u origin main

echo.
echo ========================================
echo Deployment initiated!
echo ========================================
echo.
echo Next steps:
echo 1. Go to https://github.com/%username%/%reponame%/settings/pages
echo 2. Under "Source", select "GitHub Actions"
echo 3. Wait 2-3 minutes for deployment
echo 4. Your app will be live at:
echo    https://%username%.github.io/%reponame%/
echo.
echo Important: If your repo name is NOT "GuitarSmartNeck",
echo update the base path in vite.config.ts:
echo    base: process.env.GITHUB_ACTIONS ? '/%reponame%/' : '/',
echo.

pause

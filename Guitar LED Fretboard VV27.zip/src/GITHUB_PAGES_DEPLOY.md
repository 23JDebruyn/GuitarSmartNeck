# GitHub Pages Deployment Guide

This guide will help you deploy GuitarSmartNeck to GitHub Pages to get HTTPS access for iPhone microphone functionality.

## Prerequisites

- A GitHub account
- Git installed on your computer

## Step-by-Step Deployment

### 1. Create a GitHub Repository

1. Go to [GitHub](https://github.com) and sign in
2. Click the **+** icon in the top-right corner
3. Select **New repository**
4. Name it: `GuitarSmartNeck` (or any name you prefer)
5. Make it **Public**
6. **Don't** initialize with README (we already have files)
7. Click **Create repository**

### 2. Update the Base Path (If Needed)

If you named your repository something other than `GuitarSmartNeck`, update the base path in `vite.config.ts`:

```typescript
base: process.env.GITHUB_ACTIONS ? '/YOUR-REPO-NAME/' : '/',
```

Replace `YOUR-REPO-NAME` with your actual repository name.

### 3. Initialize Git and Push to GitHub

Open a terminal in your project folder and run:

```bash
# Initialize git (if not already initialized)
git init

# Add all files
git add .

# Commit the files
git commit -m "Initial commit - GuitarSmartNeck app"

# Add your GitHub repository as remote
# Replace YOUR-USERNAME and YOUR-REPO-NAME with your actual values
git remote add origin https://github.com/YOUR-USERNAME/YOUR-REPO-NAME.git

# Push to GitHub
git branch -M main
git push -u origin main
```

### 4. Enable GitHub Pages

1. Go to your repository on GitHub
2. Click **Settings** (top menu)
3. Click **Pages** (left sidebar)
4. Under **Source**, select:
   - Source: **GitHub Actions**
5. Click **Save**

### 5. Wait for Deployment

1. Go to the **Actions** tab in your repository
2. You should see a workflow running
3. Wait for it to complete (usually 2-3 minutes)
4. Once complete, go back to **Settings → Pages**
5. You'll see your live URL: `https://YOUR-USERNAME.github.io/YOUR-REPO-NAME/`

## Testing on iPhone

1. Open Safari on your iPhone
2. Navigate to your GitHub Pages URL
3. The Tuner page should now have microphone access (HTTPS is required)
4. Add to Home Screen for full-screen PWA experience:
   - Tap the Share button
   - Scroll down and tap "Add to Home Screen"
   - Tap "Add"

## Updating Your App

Whenever you make changes:

```bash
# Stage your changes
git add .

# Commit your changes
git commit -m "Description of changes"

# Push to GitHub
git push
```

GitHub Actions will automatically rebuild and redeploy your app!

## Troubleshooting

### App doesn't load / 404 error
- Make sure the `base` path in `vite.config.ts` matches your repository name
- Check that GitHub Pages is enabled in Settings → Pages
- Wait a few minutes after pushing for the deployment to complete

### ESP32 connection issues
- Your iPhone and ESP32 must be on the same WiFi network
- Update the ESP32 IP address in Settings page
- Make sure WebSocket connections are allowed (they should work over HTTPS)

### Microphone doesn't work
- HTTPS is required for microphone access
- Make sure you're using the GitHub Pages URL (https://...)
- Grant microphone permissions when prompted
- Try in Safari (Chrome/Firefox may have different permissions)

## Alternative: Vercel Deployment

If you prefer Vercel, you can also deploy there:

```bash
# Install Vercel CLI
npm install -g vercel

# Login and deploy
vercel login
vercel
```

Vercel will give you a URL like `https://guitar-smart-neck.vercel.app`

## Support

If you have issues, check:
- GitHub Actions logs (Actions tab in your repository)
- Browser console for errors (F12 → Console)
- Make sure all dependencies are installed: `npm install`

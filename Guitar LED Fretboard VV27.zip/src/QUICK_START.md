# GuitarSmartNeck - Quick Start Guide

## 🚀 Running Locally (Development)

### Step 1: Install Node.js
Make sure you have Node.js installed:
- Download from: https://nodejs.org/
- Version 18 or higher recommended
- To check: Open terminal and run `node --version`

### Step 2: Install Dependencies
Open a terminal in this project folder and run:

```bash
npm install
```

This will download all the required packages (~2-3 minutes).

### Step 3: Start the Development Server
After installation completes, run:

```bash
npm run dev
```

OR simply double-click the **START.bat** file!

### Step 4: Open in Browser
- The terminal will show: `Local: http://localhost:5173`
- Open this URL in your browser
- For iPhone testing on the same network: Use the `Network: http://192.168.x.x:5173` URL

## 📱 For iPhone Microphone Access (Production)

The Tuner page needs HTTPS to access the microphone. You have two options:

### Option A: GitHub Pages (Recommended)
Follow the instructions in **GITHUB_PAGES_DEPLOY.md**

### Option B: Vercel
1. Install Vercel CLI: `npm install -g vercel`
2. Login: `vercel login`
3. Deploy: `vercel`

## 🎸 ESP32 Setup

1. Upload `ESP32_WiFi_Fretboard_LED.ino` to your ESP32
2. Update WiFi credentials in the Arduino code
3. Note the IP address shown in Serial Monitor
4. In the app, go to Settings and enter the ESP32 IP address
5. The app will auto-connect

## 🔧 Common Issues

### "npm: command not found"
- Install Node.js from https://nodejs.org/

### Port 5173 already in use
- Close any other apps using port 5173
- Or the app will automatically use a different port

### ESP32 won't connect
- Make sure your phone/computer and ESP32 are on the same WiFi network
- Check the IP address in Settings matches the Serial Monitor
- Try clicking "Connect" button manually

### Microphone doesn't work
- Microphone requires HTTPS (works on GitHub Pages/Vercel, not localhost)
- Deploy using GitHub Pages or Vercel for iPhone microphone access

## 📝 Development Commands

```bash
# Start development server
npm run dev

# Build for production
npm run build

# Preview production build locally
npm run preview

# Type check
npm run build:check
```

## 📂 Project Structure

- `/App.tsx` - Main app component with routing
- `/components/` - All React components (pages + UI)
- `/public/` - Static assets (icons, manifest)
- `/styles/globals.css` - Global styles and Tailwind config
- `/ESP32_WiFi_Fretboard_LED.ino` - Arduino code for ESP32

## 🆘 Need Help?

Check the detailed guides:
- **DEPLOY.md** - Deployment options
- **GITHUB_PAGES_DEPLOY.md** - GitHub Pages setup
- **PATTERN_BUTTON.md** - Pattern button feature
- **BUTTON_WIRING_DIAGRAM.txt** - Hardware wiring

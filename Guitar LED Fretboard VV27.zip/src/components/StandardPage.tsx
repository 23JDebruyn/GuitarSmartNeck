import React, { useEffect, useState } from 'react';
import { AnimatedLEDFretboard } from './AnimatedLEDFretboard';
import { useBLE } from './WiFiContext';

interface LED {
  fret: number;
  string: number;
  color?: string;
  label?: string;
}

// Standard fret marker positions
const STANDARD_MARKERS = [
  { fret: 3, strings: [3] },     // Single dot on 3rd fret (middle string)
  { fret: 5, strings: [3] },     // Single dot on 5th fret
  { fret: 7, strings: [3] },     // Single dot on 7th fret
  { fret: 9, strings: [3] },     // Single dot on 9th fret
  { fret: 12, strings: [2, 4] }, // Double dots on 12th fret (G and D strings)
  { fret: 15, strings: [3] },    // Single dot on 15th fret
  { fret: 17, strings: [3] },    // Single dot on 17th fret
  { fret: 19, strings: [3] },    // Single dot on 19th fret
  { fret: 21, strings: [3] },    // Single dot on 21st fret
  { fret: 24, strings: [2, 4] }, // Double dots on 24th fret
];

export function StandardPage() {
  const { sendLEDData } = useBLE();
  const [markerColor, setMarkerColor] = useState('#00FF00'); // Default green

  // Generate LEDs for standard fret markers
  const generateStandardMarkerLEDs = (): LED[] => {
    const leds: LED[] = [];
    
    STANDARD_MARKERS.forEach(marker => {
      marker.strings.forEach(string => {
        leds.push({
          fret: marker.fret,
          string: string,
          color: markerColor,
          label: ''
        });
      });
    });

    return leds;
  };

  const [activeLEDs, setActiveLEDs] = useState<LED[]>(generateStandardMarkerLEDs());

  // Update LEDs when color changes
  useEffect(() => {
    const leds = generateStandardMarkerLEDs();
    setActiveLEDs(leds);
  }, [markerColor]);

  // Send to BLE when LEDs change
  useEffect(() => {
    sendLEDData(activeLEDs);
  }, [activeLEDs, sendLEDData]);

  const handleLEDClick = () => {
    // No interaction needed for standard markers - they're static
  };

  const colorOptions = [
    { name: 'Green', value: '#00FF00' },
    { name: 'White', value: '#FFFFFF' },
    { name: 'Blue', value: '#0000FF' },
    { name: 'Red', value: '#FF0000' },
    { name: 'Yellow', value: '#FFFF00' },
    { name: 'Orange', value: '#FF8800' },
    { name: 'Cyan', value: '#00FFFF' },
    { name: 'Purple', value: '#FF00FF' },
  ];

  return (
    <div className="flex flex-col h-full">
      {/* Controls */}
      <div className="bg-gray-900 p-2 border-b border-gray-700">
        <div className="flex flex-col gap-2">
          <div className="text-gray-400" style={{ fontSize: '10px' }}>
            Marker Color:
          </div>
          <div className="grid grid-cols-4 gap-1">
            {colorOptions.map((color) => (
              <button
                key={color.value}
                onClick={() => setMarkerColor(color.value)}
                className={`px-1.5 py-1 rounded transition-colors ${
                  markerColor === color.value
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-700 text-gray-300'
                }`}
                style={{ fontSize: '30px' }}
              >
                {color.name}
              </button>
            ))}
          </div>
          <div className="text-gray-500" style={{ fontSize: '9px' }}>
            Fret markers: 3, 5, 7, 9, 12 (double), 15, 17, 19, 21, 24 (double)
          </div>
        </div>
      </div>

      {/* Fretboard */}
      <div className="flex-1 overflow-hidden">
        <AnimatedLEDFretboard
          activeLEDs={activeLEDs}
          onLEDClick={handleLEDClick}
        />
      </div>
    </div>
  );
}

import React, { useState, useCallback, useRef } from 'react';
import { useBLE } from './WiFiContext';
import { Zap } from 'lucide-react';

interface HomePageProps {
  onNavigate: (page: 'Standard' | 'Chords' | 'Pentatonic') => void;
}

export function HomePage({ onNavigate }: HomePageProps) {
  const { sendLEDData, clearLEDs, isConnected } = useBLE();
  const [isPlaying, setIsPlaying] = useState(false);
  const [currentPattern, setCurrentPattern] = useState(0);
  const animationRef = useRef<boolean>(false);

  // Pattern 1: Light up bars one after another in white, red, blue, green, then clear
  const pattern1BarFill = useCallback(async () => {
    animationRef.current = true;
    const colors = [
      { r: 255, g: 255, b: 255, name: 'White' }, // White
      { r: 255, g: 0, b: 0, name: 'Red' },       // Red
      { r: 0, g: 0, b: 255, name: 'Blue' },      // Blue
      { r: 0, g: 255, b: 0, name: 'Green' }      // Green
    ];

    for (const color of colors) {
      if (!animationRef.current) return;
      
      // Light up each string sequentially
      for (let string = 0; string < 6; string++) {
        if (!animationRef.current) return;
        
        const leds = [];
        // Light all previous strings
        for (let s = 0; s <= string; s++) {
          for (let fret = 0; fret < 24; fret++) {
            leds.push({
              string: s,
              fret: fret,
              r: color.r,
              g: color.g,
              b: color.b,
            });
          }
        }
        
        await sendLEDData(leds);
        await new Promise(resolve => setTimeout(resolve, 150));
      }
      
      // Hold all strings lit
      await new Promise(resolve => setTimeout(resolve, 500));
    }
    
    // Clear
    await clearLEDs();
  }, [sendLEDData, clearLEDs]);

  // Pattern 2: Wave over all frets
  const pattern2Wave = useCallback(async () => {
    animationRef.current = true;
    const waveLength = 6; // Number of frets in the wave
    const totalSteps = 24 + waveLength;
    
    for (let step = 0; step < totalSteps; step++) {
      if (!animationRef.current) return;
      
      const leds = [];
      
      for (let string = 0; string < 6; string++) {
        for (let offset = 0; offset < waveLength; offset++) {
          const fret = step - offset;
          if (fret >= 0 && fret < 24) {
            // Create color gradient in the wave
            const intensity = Math.floor(255 * (waveLength - offset) / waveLength);
            leds.push({
              string: string,
              fret: fret,
              r: 0,
              g: intensity,
              b: 255 - intensity,
            });
          }
        }
      }
      
      await sendLEDData(leds);
      await new Promise(resolve => setTimeout(resolve, 50));
    }
    
    await clearLEDs();
  }, [sendLEDData, clearLEDs]);

  // Pattern 3: All LEDs on with each string in different color
  const pattern3Rainbow = useCallback(async () => {
    animationRef.current = true;
    const stringColors = [
      { r: 255, g: 0, b: 0 },     // String 0 (High E) - Red
      { r: 255, g: 165, b: 0 },   // String 1 (B) - Orange
      { r: 255, g: 255, b: 0 },   // String 2 (G) - Yellow
      { r: 0, g: 255, b: 0 },     // String 3 (D) - Green
      { r: 0, g: 0, b: 255 },     // String 4 (A) - Blue
      { r: 128, g: 0, b: 128 },   // String 5 (Low E) - Purple
    ];

    const leds = [];
    for (let string = 0; string < 6; string++) {
      for (let fret = 0; fret < 24; fret++) {
        leds.push({
          string: string,
          fret: fret,
          r: stringColors[string].r,
          g: stringColors[string].g,
          b: stringColors[string].b,
        });
      }
    }
    
    await sendLEDData(leds);
    await new Promise(resolve => setTimeout(resolve, 2000));
    await clearLEDs();
  }, [sendLEDData, clearLEDs]);

  // Execute pattern cycle
  const cyclePattern = useCallback(async () => {
    if (isPlaying || !isConnected) return;
    
    setIsPlaying(true);
    animationRef.current = true;
    
    // Calculate next pattern (0-5)
    const nextPattern = (currentPattern + 1) % 6;
    setCurrentPattern(nextPattern);
    
    try {
      switch (nextPattern) {
        case 0:
          // Pattern 1: Bar fill
          await pattern1BarFill();
          break;
        case 1:
          // Pattern 2: Wave
          await pattern2Wave();
          break;
        case 2:
          // Pattern 3: Rainbow
          await pattern3Rainbow();
          break;
        case 3:
          // Pattern 4: Navigate to Standard (Fret indicators)
          await clearLEDs();
          onNavigate('Standard');
          break;
        case 4:
          // Pattern 5: Navigate to Chords
          await clearLEDs();
          onNavigate('Chords');
          break;
        case 5:
          // Pattern 6: Navigate to Pentatonic
          await clearLEDs();
          onNavigate('Pentatonic');
          break;
      }
    } catch (error) {
      console.error('Pattern error:', error);
    } finally {
      animationRef.current = false;
      setIsPlaying(false);
    }
  }, [isPlaying, isConnected, currentPattern, pattern1BarFill, pattern2Wave, pattern3Rainbow, clearLEDs, onNavigate]);

  const getPatternName = (patternNum: number): string => {
    const names = [
      'Bar Fill (White/Red/Blue/Green)',
      'Wave Pattern',
      'Rainbow Strings',
      'Fret Indicators',
      'Chord Page',
      'Pentatonic Page'
    ];
    return names[patternNum] || 'Unknown';
  };

  return (
    <div className="h-full flex flex-col items-center justify-center bg-gradient-to-b from-gray-900 to-black text-white p-4">
      <div className="flex flex-col items-center space-y-6 max-w-md">
        {/* Logo/Title */}
        <div className="text-center space-y-2">
          <h1 className="text-4xl tracking-wider text-blue-400">
            GuitarSmartNeck
          </h1>
          <p className="text-gray-400">
            Interactive LED Fretboard
          </p>
        </div>

        {/* Pattern Cycle Button */}
        <div className="flex flex-col items-center space-y-4 w-full">
          <button
            onClick={cyclePattern}
            disabled={!isConnected || isPlaying}
            className={`w-full h-20 text-xl rounded-lg flex items-center justify-center transition-all transform ${
              !isConnected || isPlaying
                ? 'bg-gradient-to-r from-gray-700 to-gray-800 cursor-not-allowed opacity-50'
                : 'bg-gradient-to-r from-blue-600 to-purple-600 hover:from-blue-700 hover:to-purple-700 hover:scale-105 cursor-pointer shadow-lg'
            }`}
          >
            <Zap className="mr-3 h-8 w-8" />
            {isPlaying ? 'Playing Pattern...' : 'Pattern Cycle'}
          </button>

          {/* Current Pattern Info */}
          <div className="text-center space-y-1">
            <p className="text-sm text-gray-400">Next Pattern:</p>
            <p className="text-lg text-blue-300">
              {getPatternName((currentPattern + 1) % 6)}
            </p>
          </div>
        </div>

        {/* Connection Status */}
        {!isConnected && (
          <div className="mt-8 p-4 bg-yellow-900/20 border border-yellow-700 rounded-lg">
            <p className="text-sm text-yellow-300 text-center">
              ⚠️ Connect to ESP32 in Settings to use patterns
            </p>
          </div>
        )}

        {/* Pattern Legend */}
        <div className="mt-8 w-full space-y-2 text-sm text-gray-400">
          <p className="text-center text-xs uppercase tracking-wider text-gray-500 mb-3">
            Pattern Sequence
          </p>
          {[0, 1, 2, 3, 4, 5].map((num) => (
            <div
              key={num}
              className={`p-2 rounded transition-all ${
                (currentPattern + 1) % 6 === num
                  ? 'bg-blue-900/30 border border-blue-700 text-blue-300'
                  : 'bg-gray-800/30'
              }`}
            >
              <span className="text-gray-500 mr-2">{num + 1}.</span>
              {getPatternName(num)}
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

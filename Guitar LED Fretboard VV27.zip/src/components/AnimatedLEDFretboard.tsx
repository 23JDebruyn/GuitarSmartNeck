import React, { useEffect, useState } from 'react';
import { useBLE } from './WiFiContext';

interface LED {
  fret: number;
  string: number;
  color?: string;
  colors?: string[]; // Multiple colors for animation
  label?: string;
}

interface AnimatedLEDFretboardProps {
  activeLEDs: LED[];
  onLEDClick: (fret: number, string: number) => void;
}

const STRINGS = ['E', 'B', 'G', 'D', 'A', 'E'];
const FRETS = 24;
const FRET_MARKERS = [3, 5, 7, 9, 12, 15, 17, 19, 21, 24];

export function AnimatedLEDFretboard({ activeLEDs, onLEDClick }: AnimatedLEDFretboardProps) {
  const { orientation } = useBLE();
  const scrollContainerRef = React.useRef<HTMLDivElement>(null);
  const [colorIndex, setColorIndex] = useState(0);

  const isLEDActive = (fret: number, string: number) => {
    return activeLEDs.find(led => led.fret === fret && led.string === string);
  };

  // Animate between colors for multi-color LEDs
  useEffect(() => {
    const interval = setInterval(() => {
      setColorIndex(prev => prev + 1);
    }, 800); // Change color every 800ms

    return () => clearInterval(interval);
  }, []);

  // Auto-scroll to show active LEDs
  React.useEffect(() => {
    if (activeLEDs.length === 0 || !scrollContainerRef.current) return;

    const frets = activeLEDs.map(led => led.fret);
    const minFret = Math.min(...frets);
    const maxFret = Math.max(...frets);
    const centerFret = Math.floor((minFret + maxFret) / 2);

    if (orientation === 'horizontal') {
      const fretWidth = 59; // Increased by 30% from 45px
      const nutWidth = 29; // Increased by 30% from 22px
      const scrollPosition = centerFret === 0 ? 0 : nutWidth + (centerFret - 1) * fretWidth;
      scrollContainerRef.current.scrollTo({
        left: scrollPosition - scrollContainerRef.current.clientWidth / 2 + fretWidth / 2,
        behavior: 'smooth'
      });
    } else {
      const fretHeight = 36; // Increased by 30% from 28px
      const nutHeight = 18; // Increased by 30% from 14px
      const scrollPosition = centerFret === 0 ? 0 : nutHeight + (centerFret - 1) * fretHeight;
      scrollContainerRef.current.scrollTo({
        top: scrollPosition - scrollContainerRef.current.clientHeight / 2 + fretHeight / 2,
        behavior: 'smooth'
      });
    }
  }, [activeLEDs, orientation]);

  const getLEDColor = (led: LED) => {
    if (led.colors && led.colors.length > 1) {
      // Cycle through colors
      return led.colors[colorIndex % led.colors.length];
    }
    return led.color || '#60a5fa';
  };

  if (orientation === 'vertical') {
    // Vertical orientation
    return (
      <div ref={scrollContainerRef} className="h-full overflow-y-auto">
        <div className="inline-block min-h-full p-2 sm:p-4">
          <div className="relative flex">
            {/* Fret numbers on the left */}
            <div className="flex flex-col mr-2 mt-6 sm:mt-10">
              {Array.from({ length: FRETS + 1 }, (_, i) => (
                <div
                  key={i}
                  className="flex-shrink-0 text-center text-gray-400"
                  style={{ 
                    height: i === 0 ? '18px' : '36px',
                    fontSize: '8px',
                    display: 'flex',
                    alignItems: 'center'
                  }}
                >
                  {i}
                </div>
              ))}
            </div>

            {/* Strings */}
            <div className="flex-1">
              {/* String names */}
              <div className="flex gap-0.5 sm:gap-1 mb-2">
                {STRINGS.map((stringName, idx) => (
                  <div 
                    key={idx} 
                    className="flex-1 text-center text-gray-300" 
                    style={{ fontSize: '8px' }}
                  >
                    {stringName}
                  </div>
                ))}
              </div>

              {/* Fret positions */}
              {Array.from({ length: FRETS + 1 }, (_, fretIndex) => {
                const isNut = fretIndex === 0;
                return (
                  <div key={fretIndex} className="flex gap-0.5 sm:gap-1">
                    {STRINGS.map((_, stringIndex) => {
                      const led = isLEDActive(fretIndex, stringIndex);
                      const currentColor = led ? getLEDColor(led) : undefined;
                      
                      return (
                        <div
                          key={stringIndex}
                          className="flex-1 relative"
                          style={{ height: isNut ? '18px' : '36px' }}
                        >
                          {/* Fret line */}
                          {fretIndex > 0 && (
                            <div className="absolute top-0 left-0 right-0 h-0.5 sm:h-1 bg-gray-400" />
                          )}
                          
                          {/* Nut (fret 0) */}
                          {isNut && (
                            <div className="absolute top-0 left-0 right-0 h-1 sm:h-2 bg-gray-200" />
                          )}

                          {/* String line */}
                          <div 
                            className="absolute left-1/2 top-0 bottom-0 bg-gradient-to-r from-gray-300 to-gray-400"
                            style={{ 
                              width: `${0.8 + (5 - stringIndex) * 0.24}px`,
                              transform: 'translateX(-50%)'
                            }}
                          />

                          {/* LED position */}
                          <button
                            onClick={() => onLEDClick(fretIndex, stringIndex)}
                            className={`
                              absolute rounded-full border-2 z-10 flex items-center justify-center
                              ${led 
                                ? 'border-transparent shadow-lg scale-110' 
                                : 'border-gray-600 bg-gray-800 hover:bg-gray-700 hover:border-gray-500'
                              }
                            `}
                            style={{
                              width: '14px',
                              height: '14px',
                              left: '50%',
                              top: isNut ? '4px' : '50%',
                              transform: isNut ? 'translateX(-50%)' : 'translate(-50%, -50%)',
                              backgroundColor: currentColor,
                              boxShadow: led ? `0 0 10px ${currentColor}` : undefined,
                              transition: 'background-color 0.8s ease-in-out, box-shadow 0.8s ease-in-out'
                            }}
                          >
                            {led?.label && (
                              <span className="text-white" style={{ fontSize: '5px' }}>
                                {led.label}
                              </span>
                            )}
                          </button>

                          {/* Fret marker dots */}
                          {stringIndex === 2 && FRET_MARKERS.includes(fretIndex) && (
                            <div 
                              className="absolute rounded-full bg-gray-600"
                              style={{
                                width: '5px',
                                height: '5px',
                                right: '-9px',
                                top: '50%',
                                transform: 'translateY(-50%)'
                              }}
                            />
                          )}
                        </div>
                      );
                    })}
                  </div>
                );
              })}
            </div>
          </div>
        </div>
      </div>
    );
  }

  // Horizontal orientation (default)
  return (
    <div ref={scrollContainerRef} className="h-full overflow-x-auto">
      <div className="inline-block h-full p-4">
        <div className="relative h-full flex flex-col justify-center">
          {/* Fret numbers */}
          <div className="flex mb-2 ml-12">
            {Array.from({ length: FRETS + 1 }, (_, i) => (
              <div
                key={i}
                className="flex-shrink-0 text-center text-gray-400"
                style={{ 
                  width: i === 0 ? '29px' : '59px',
                  fontSize: '10px'
                }}
              >
                {i}
              </div>
            ))}
          </div>

          {/* Strings */}
          <div className="relative">
            {STRINGS.map((stringName, stringIndex) => (
              <div key={stringIndex} className="flex items-center mb-2">
                {/* String name */}
                <div className="w-9 text-center text-gray-300 mr-2" style={{ fontSize: '13px' }}>
                  {stringName}
                </div>

                {/* String line with frets */}
                <div className="flex items-center relative">
                  {/* The string line */}
                  <div 
                    className="absolute left-0 right-0 bg-gradient-to-b from-gray-300 to-gray-400"
                    style={{ 
                      height: `${(1.6 + stringIndex * 0.4) * 0.91}px`,
                      top: '50%',
                      transform: 'translateY(-50%)'
                    }}
                  />

                  {/* Fret positions */}
                  {Array.from({ length: FRETS + 1 }, (_, fretIndex) => {
                    const led = isLEDActive(fretIndex, stringIndex);
                    const isNut = fretIndex === 0;
                    const currentColor = led ? getLEDColor(led) : undefined;
                    
                    return (
                      <div
                        key={fretIndex}
                        className="flex-shrink-0 relative"
                        style={{ width: isNut ? '29px' : '59px', height: '35px' }}
                      >
                        {/* Fret line */}
                        {fretIndex > 0 && (
                          <div className="absolute left-0 h-full bg-gray-400" style={{ width: '1.1px', top: '-9px' }} />
                        )}
                        
                        {/* Nut (fret 0) */}
                        {isNut && (
                          <div className="absolute left-0 h-full bg-gray-200" style={{ width: '2.2px', top: '-9px' }} />
                        )}

                        {/* LED position */}
                        <button
                          onClick={() => onLEDClick(fretIndex, stringIndex)}
                          className={`
                            absolute rounded-full border-2 z-10 flex items-center justify-center
                            ${led 
                              ? 'border-transparent shadow-lg scale-110' 
                              : 'border-gray-600 bg-gray-800 hover:bg-gray-700 hover:border-gray-500'
                            }
                          `}
                          style={{
                            width: '23px',
                            height: '23px',
                            left: isNut ? '9px' : '50%',
                            top: '50%',
                            transform: isNut ? 'translate(0, -50%)' : 'translate(-50%, -50%)',
                            backgroundColor: currentColor,
                            boxShadow: led ? `0 0 14px ${currentColor}` : undefined,
                            transition: 'background-color 0.8s ease-in-out, box-shadow 0.8s ease-in-out',
                            fontSize: '9px'
                          }}
                        >
                          {led?.label && (
                            <span className="text-white" style={{ fontSize: '9px' }}>
                              {led.label}
                            </span>
                          )}
                        </button>

                        {/* Fret marker dots */}
                        {stringIndex === 2 && FRET_MARKERS.includes(fretIndex) && (
                          <div 
                            className="absolute rounded-full bg-gray-600"
                            style={{
                              width: '9px',
                              height: '9px',
                              left: '50%',
                              bottom: '-13px',
                              transform: 'translateX(-50%)'
                            }}
                          />
                        )}
                      </div>
                    );
                  })}
                </div>
              </div>
            ))}
          </div>
        </div>
      </div>
    </div>
  );
}

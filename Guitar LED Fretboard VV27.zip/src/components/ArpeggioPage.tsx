import React, { useState } from 'react';
import { AnimatedLEDFretboard } from './AnimatedLEDFretboard';
import { useBLE } from './WiFiContext';

interface LED {
  fret: number;
  string: number;
  color?: string;
  label?: string;
}

// Arpeggio patterns - CAGED system positions
// Format: [string index (0-5), fret offset from root, interval]
const ARPEGGIO_PATTERNS = {
  // Major Triad (R, 3, 5)
  'Major': {
    'Pattern 1 (E shape)': [
      [0, 0, 'R'], [1, 0, '5'], [1, 3, 'R'], [2, 2, '3'], [3, 2, '5'], [4, 3, '3'], [5, 3, 'R']
    ],
    'Pattern 2 (D shape)': [
      [0, 3, '3'], [1, 3, 'R'], [2, 3, '3'], [3, 2, '5'], [4, 3, '3'], [5, 3, 'R']
    ],
    'Pattern 3 (C shape)': [
      [0, 3, 'R'], [1, 4, '3'], [2, 3, '5'], [3, 3, '5'], [4, 3, '3'], [5, 3, '5']
    ],
    'Pattern 4 (A shape)': [
      [0, 3, '3'], [1, 4, '3'], [2, 3, '5'], [3, 3, 'R'], [4, 4, '5'], [5, 3, 'R']
    ],
    'Pattern 5 (G shape)': [
      [0, 3, '3'], [1, 4, '3'], [2, 4, '5'], [3, 4, '3'], [4, 4, '5'], [5, 3, '5']
    ]
  },
  // Minor Triad (R, b3, 5)
  'Minor': {
    'Pattern 1 (E shape)': [
      [0, 0, 'R'], [1, 0, '5'], [1, 3, 'R'], [2, 1, 'b3'], [3, 2, '5'], [4, 2, 'b3'], [5, 3, 'R']
    ],
    'Pattern 2 (D shape)': [
      [0, 2, 'b3'], [1, 3, 'R'], [2, 2, 'b3'], [3, 2, '5'], [4, 2, 'b3'], [5, 3, 'R']
    ],
    'Pattern 3 (C shape)': [
      [0, 3, 'R'], [1, 3, 'b3'], [2, 3, '5'], [3, 2, '5'], [4, 3, 'b3'], [5, 2, '5']
    ],
    'Pattern 4 (A shape)': [
      [0, 3, 'b3'], [1, 4, 'b3'], [2, 3, '5'], [3, 2, 'R'], [4, 3, '5'], [5, 3, 'R']
    ],
    'Pattern 5 (G shape)': [
      [0, 3, 'b3'], [1, 4, 'b3'], [2, 3, '5'], [3, 4, 'b3'], [4, 4, '5'], [5, 2, '5']
    ]
  },
  // Dominant 7th (R, 3, 5, b7)
  'Dom7': {
    'Pattern 1 (E shape)': [
      [0, 0, 'R'], [0, 3, '3'], [1, 0, '5'], [1, 1, 'b7'], [1, 3, 'R'], [2, 0, 'b7'], [2, 2, '3'], 
      [3, 0, '5'], [3, 2, '5'], [4, 0, 'R'], [4, 3, '3'], [5, 0, '5'], [5, 3, 'R']
    ],
    'Pattern 2 (D shape)': [
      [0, 3, '3'], [1, 1, 'b7'], [1, 3, 'R'], [2, 0, 'b7'], [2, 3, '3'], [3, 0, '5'], [3, 2, '5'],
      [4, 0, 'R'], [4, 3, '3'], [5, 1, 'b7'], [5, 3, 'R']
    ],
    'Pattern 3 (C shape)': [
      [0, 1, 'b7'], [0, 3, 'R'], [1, 1, 'b7'], [1, 4, '3'], [2, 1, '3'], [2, 3, '5'], 
      [3, 0, '5'], [3, 3, '5'], [4, 1, 'b7'], [4, 3, '3'], [5, 0, '5'], [5, 3, '5']
    ],
    'Pattern 4 (A shape)': [
      [0, 1, 'b7'], [0, 3, '3'], [1, 1, 'b7'], [1, 4, '3'], [2, 1, '3'], [2, 3, '5'],
      [3, 1, 'R'], [3, 3, 'R'], [4, 1, 'b7'], [4, 4, '5'], [5, 1, 'R'], [5, 3, 'R']
    ],
    'Pattern 5 (G shape)': [
      [0, 0, 'R'], [0, 3, '3'], [1, 1, 'b7'], [1, 4, '3'], [2, 1, '3'], [2, 4, '5'],
      [3, 1, 'R'], [3, 4, '3'], [4, 1, 'b7'], [4, 4, '5'], [5, 0, '5'], [5, 3, '5']
    ]
  },
  // Major 7th (R, 3, 5, 7)
  'Maj7': {
    'Pattern 1 (E shape)': [
      [0, 0, 'R'], [0, 3, '3'], [1, 0, '5'], [1, 2, '7'], [1, 3, 'R'], [2, 1, '7'], [2, 2, '3'],
      [3, 1, '5'], [3, 2, '5'], [4, 0, 'R'], [4, 3, '3'], [5, 0, '5'], [5, 3, 'R']
    ],
    'Pattern 2 (D shape)': [
      [0, 3, '3'], [1, 2, '7'], [1, 3, 'R'], [2, 1, '7'], [2, 3, '3'], [3, 1, '5'], [3, 2, '5'],
      [4, 0, 'R'], [4, 3, '3'], [5, 2, '7'], [5, 3, 'R']
    ],
    'Pattern 3 (C shape)': [
      [0, 2, '7'], [0, 3, 'R'], [1, 2, '7'], [1, 4, '3'], [2, 1, '3'], [2, 3, '5'],
      [3, 1, '5'], [3, 3, '5'], [4, 2, '7'], [4, 3, '3'], [5, 1, '5'], [5, 3, '5']
    ],
    'Pattern 4 (A shape)': [
      [0, 2, '7'], [0, 3, '3'], [1, 2, '7'], [1, 4, '3'], [2, 1, '3'], [2, 3, '5'],
      [3, 1, 'R'], [3, 3, 'R'], [4, 2, '7'], [4, 4, '5'], [5, 1, 'R'], [5, 3, 'R']
    ],
    'Pattern 5 (G shape)': [
      [0, 0, 'R'], [0, 3, '3'], [1, 2, '7'], [1, 4, '3'], [2, 1, '3'], [2, 4, '5'],
      [3, 1, 'R'], [3, 4, '3'], [4, 2, '7'], [4, 4, '5'], [5, 1, '5'], [5, 3, '5']
    ]
  },
  // Minor 7th (R, b3, 5, b7)
  'Min7': {
    'Pattern 1 (E shape)': [
      [0, 0, 'R'], [0, 2, 'b3'], [1, 0, '5'], [1, 1, 'b7'], [1, 3, 'R'], [2, 0, 'b7'], [2, 1, 'b3'],
      [3, 0, '5'], [3, 2, '5'], [4, 0, 'R'], [4, 2, 'b3'], [5, 0, '5'], [5, 3, 'R']
    ],
    'Pattern 2 (D shape)': [
      [0, 2, 'b3'], [1, 1, 'b7'], [1, 3, 'R'], [2, 0, 'b7'], [2, 2, 'b3'], [3, 0, '5'], [3, 2, '5'],
      [4, 0, 'R'], [4, 2, 'b3'], [5, 1, 'b7'], [5, 3, 'R']
    ],
    'Pattern 3 (C shape)': [
      [0, 1, 'b7'], [0, 3, 'R'], [1, 1, 'b7'], [1, 3, 'b3'], [2, 0, 'b3'], [2, 3, '5'],
      [3, 0, '5'], [3, 2, '5'], [4, 1, 'b7'], [4, 3, 'b3'], [5, 0, '5'], [5, 2, '5']
    ],
    'Pattern 4 (A shape)': [
      [0, 1, 'b7'], [0, 3, 'b3'], [1, 1, 'b7'], [1, 4, 'b3'], [2, 1, 'b3'], [2, 3, '5'],
      [3, 1, 'R'], [3, 2, 'R'], [4, 1, 'b7'], [4, 3, '5'], [5, 1, 'R'], [5, 3, 'R']
    ],
    'Pattern 5 (G shape)': [
      [0, 0, 'R'], [0, 3, 'b3'], [1, 1, 'b7'], [1, 4, 'b3'], [2, 1, 'b3'], [2, 3, '5'],
      [3, 1, 'R'], [3, 4, 'b3'], [4, 1, 'b7'], [4, 4, '5'], [5, 0, '5'], [5, 2, '5']
    ]
  },
  // Diminished (R, b3, b5)
  'Dim': {
    'Pattern 1 (E shape)': [
      [0, 0, 'R'], [1, 0, 'b5'], [1, 3, 'R'], [2, 1, 'b3'], [3, 1, 'b5'], [4, 2, 'b3'], [5, 2, 'b5']
    ],
    'Pattern 2 (D shape)': [
      [0, 2, 'b3'], [1, 2, 'b5'], [2, 2, 'b3'], [3, 1, 'b5'], [4, 2, 'b3'], [5, 2, 'b5']
    ],
    'Pattern 3 (C shape)': [
      [0, 2, 'b5'], [1, 3, 'b3'], [2, 2, 'b5'], [3, 2, 'b5'], [4, 3, 'b3'], [5, 2, 'b5']
    ],
    'Pattern 4 (A shape)': [
      [0, 3, 'b3'], [1, 3, 'b3'], [2, 2, 'b5'], [3, 2, 'R'], [4, 3, 'b5'], [5, 3, 'R']
    ],
    'Pattern 5 (G shape)': [
      [0, 3, 'b3'], [1, 3, 'b3'], [2, 3, 'b5'], [4, 3, 'b5'], [5, 2, 'b5']
    ]
  },
  // Augmented (R, 3, #5)
  'Aug': {
    'Pattern 1 (E shape)': [
      [0, 0, 'R'], [1, 1, '#5'], [1, 3, 'R'], [2, 2, '3'], [3, 3, '#5'], [4, 3, '3'], [5, 4, '#5']
    ],
    'Pattern 2 (D shape)': [
      [0, 3, '3'], [1, 1, '#5'], [2, 3, '3'], [3, 3, '#5'], [4, 3, '3'], [5, 4, '#5']
    ],
    'Pattern 3 (C shape)': [
      [0, 4, '#5'], [1, 4, '3'], [2, 4, '#5'], [3, 3, '#5'], [4, 3, '3'], [5, 4, '#5']
    ],
    'Pattern 4 (A shape)': [
      [0, 3, '3'], [1, 1, '#5'], [2, 4, '#5'], [3, 3, 'R'], [4, 1, '#5'], [5, 3, 'R']
    ],
    'Pattern 5 (G shape)': [
      [0, 3, '3'], [1, 1, '#5'], [2, 4, '#5'], [3, 4, '3'], [4, 1, '#5'], [5, 4, '#5']
    ]
  }
};

// Root note positions on the 6th string (Low E) for each key
const ROOT_POSITIONS: { [key: string]: number } = {
  'E': 0, 'F': 1, 'F#': 2, 'G': 3, 'G#': 4, 'A': 5, 'A#': 6, 'B': 7,
  'C': 8, 'C#': 9, 'D': 10, 'D#': 11
};

// Keys available
const KEYS = ['E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B', 'C', 'C#', 'D', 'D#'];

// Arpeggio types
const ARPEGGIO_TYPES = ['Major', 'Minor', 'Dom7', 'Maj7', 'Min7', 'Dim', 'Aug'];

// Position colors - Each CAGED position gets a unique color
const POSITION_COLORS = {
  'Pattern 1 (E shape)': '#ff0000',  // Bright Red
  'Pattern 2 (D shape)': '#00ff00',  // Bright Green
  'Pattern 3 (C shape)': '#0080ff',  // Bright Blue
  'Pattern 4 (A shape)': '#ffaa00',  // Bright Orange
  'Pattern 5 (G shape)': '#ff00ff',  // Bright Magenta
};

export function ArpeggioPage() {
  const { sendLEDData } = useBLE();
  const [selectedKey, setSelectedKey] = useState<string>('A');
  const [selectedArpeggioType, setSelectedArpeggioType] = useState<string>('Major');
  const [selectedPattern, setSelectedPattern] = useState<string>('Pattern 1 (E shape)');
  const [activeLEDs, setActiveLEDs] = useState<LED[]>([]);

  React.useEffect(() => {
    displayArpeggio(selectedKey, selectedArpeggioType, selectedPattern);
  }, [selectedKey, selectedArpeggioType, selectedPattern]);

  const displayArpeggio = (key: string, arpeggioType: string, pattern: string) => {
    const rootFret = ROOT_POSITIONS[key];
    const allLeds: LED[] = [];
    
    // Calculate position offset for each pattern
    const patternOffsets = {
      'Pattern 1 (E shape)': 0,
      'Pattern 2 (D shape)': 2,
      'Pattern 3 (C shape)': 5,
      'Pattern 4 (A shape)': 7,
      'Pattern 5 (G shape)': 10
    };
    
    // Get color for the selected pattern
    const patternColor = POSITION_COLORS[pattern as keyof typeof POSITION_COLORS];
    const baseOffset = patternOffsets[pattern as keyof typeof patternOffsets] || 0;
    const patternData = ARPEGGIO_PATTERNS[arpeggioType as keyof typeof ARPEGGIO_PATTERNS]?.[pattern as keyof typeof ARPEGGIO_PATTERNS['Major']];
    
    if (!patternData) return;
    
    // Display only the selected pattern
    patternData.forEach(([stringIndex, fretOffset, interval]) => {
      const fret = rootFret + baseOffset + fretOffset;
      
      // Only add if within 24 frets
      if (fret >= 0 && fret <= 24) {
        allLeds.push({
          fret: fret,
          string: stringIndex as number,
          color: patternColor,
          label: interval as string,
        });
      }
    });
    
    setActiveLEDs(allLeds);
    
    // Send to ESP32 via WiFi
    sendLEDData(allLeds);
  };

  const handleLEDClick = (fret: number, string: number) => {
    console.log(`Clicked: String ${string}, Fret ${fret}`);
  };

  const patterns = Object.keys(POSITION_COLORS);

  return (
    <div className="flex flex-col h-full bg-black">
      {/* Fretboard Display */}
      <div className="flex-1 overflow-hidden">
        <AnimatedLEDFretboard activeLEDs={activeLEDs} onLEDClick={handleLEDClick} />
      </div>

      {/* Controls */}
      <div className="p-2 bg-gray-950">
        {/* Arpeggio Type Selector */}
        <div className="mb-2">
          <div className="flex gap-1 justify-center flex-wrap">
            {ARPEGGIO_TYPES.map((arpeggioType) => (
              <button
                key={arpeggioType}
                onClick={() => setSelectedArpeggioType(arpeggioType)}
                className={`py-1 px-2 rounded transition-colors text-xs flex items-center justify-center ${
                  selectedArpeggioType === arpeggioType
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {arpeggioType}
              </button>
            ))}
          </div>
        </div>

        {/* Position Selector */}
        <div className="mb-2">
          <div className="flex gap-1 justify-center">
            {patterns.map((pattern, index) => {
              const positionColor = POSITION_COLORS[pattern as keyof typeof POSITION_COLORS];
              return (
                <button
                  key={pattern}
                  onClick={() => setSelectedPattern(pattern)}
                  className={`py-1 px-2 rounded transition-colors flex items-center justify-center min-w-[24px] ${
                    selectedPattern === pattern
                      ? 'text-white ring-2 ring-white'
                      : 'text-gray-300 hover:ring-2 hover:ring-gray-500'
                  }`}
                  style={{
                    backgroundColor: selectedPattern === pattern ? positionColor : '#1f2937'
                  }}
                >
                  {index + 1}
                </button>
              );
            })}
          </div>
        </div>

        {/* Key Selector */}
        <div className="mb-2">
          <div className="flex flex-wrap gap-1 justify-center max-w-4xl mx-auto">
            {KEYS.map((key) => (
              <button
                key={key}
                onClick={() => setSelectedKey(key)}
                className={`py-0.5 px-1.5 rounded transition-colors min-w-[18px] flex items-center justify-center text-xl ${
                  selectedKey === key
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {key}
              </button>
            ))}
          </div>
        </div>

        {/* Current Position Info */}
        <div className="flex gap-2 justify-center text-xs">
          <div className="flex items-center gap-1">
            <div
              className="w-3 h-3 rounded-full"
              style={{ 
                backgroundColor: POSITION_COLORS[selectedPattern as keyof typeof POSITION_COLORS], 
                boxShadow: `0 0 6px ${POSITION_COLORS[selectedPattern as keyof typeof POSITION_COLORS]}` 
              }}
            />
            <span className="text-gray-300">
              {selectedPattern.replace(' (', ' - ').replace(' shape)', '')}
            </span>
          </div>
        </div>
      </div>
    </div>
  );
}

import React, { useState, useEffect } from 'react';
import { AnimatedLEDFretboard } from './AnimatedLEDFretboard';
import { useBLE } from './WiFiContext';

interface LED {
  fret: number;
  string: number;
  color?: string;
  colors?: string[];
  label?: string;
}

// Chord voicings - single position for each chord (using open/common positions)
const CHORD_SHAPES: { [key: string]: number[][] } = {
  // Major Chords
  'C': [[0, 0, 0], [1, 1, 1], [2, 0, 0], [3, 2, 2], [4, 3, 3]],
  'D': [[0, 2, 2], [1, 3, 3], [2, 2, 1], [3, 0, 0]],
  'E': [[0, 0, 0], [1, 0, 0], [2, 1, 1], [3, 2, 3], [4, 2, 2], [5, 0, 0]],
  'F': [[0, 1, 1], [1, 1, 1], [2, 2, 2], [3, 3, 4], [4, 3, 3], [5, 1, 1]],
  'G': [[0, 3, 3], [1, 0, 0], [2, 0, 0], [3, 0, 0], [4, 2, 1], [5, 3, 4]],
  'A': [[0, 0, 0], [1, 2, 3], [2, 2, 2], [3, 2, 1], [4, 0, 0]],
  'B': [[0, 2, 1], [1, 2, 1], [2, 3, 2], [3, 4, 4], [4, 4, 3], [5, 2, 1]],
  'Bb': [[0, 1, 1], [1, 3, 3], [2, 3, 2], [3, 3, 1], [4, 1, 1]],
  'F#': [[0, 2, 1], [1, 2, 1], [2, 3, 2], [3, 4, 4], [4, 4, 3], [5, 2, 1]], // Same shape as B barre
  
  // Minor Chords
  'Am': [[0, 0, 0], [1, 1, 1], [2, 2, 3], [3, 2, 2], [4, 0, 0]],
  'Bm': [[0, 2, 1], [1, 3, 3], [2, 4, 4], [3, 4, 2], [4, 2, 1]],
  'Cm': [[0, 3, 1], [1, 3, 1], [2, 4, 2], [3, 5, 4], [4, 5, 3], [5, 3, 1]],
  'Dm': [[0, 1, 1], [1, 3, 3], [2, 2, 2], [3, 0, 0]],
  'Em': [[0, 0, 0], [1, 0, 0], [2, 0, 0], [3, 2, 2], [4, 2, 1], [5, 0, 0]],
  'Fm': [[0, 1, 1], [1, 1, 1], [2, 1, 1], [3, 3, 4], [4, 3, 3], [5, 1, 1]],
  'Gm': [[0, 3, 1], [1, 3, 1], [2, 3, 1], [3, 5, 4], [4, 5, 3], [5, 3, 1]],
  'C#m': [[0, 4, 1], [1, 4, 1], [2, 5, 2], [3, 6, 4], [4, 6, 3], [5, 4, 1]],
  'F#m': [[0, 2, 1], [1, 2, 1], [2, 2, 1], [3, 4, 4], [4, 4, 3], [5, 2, 1]],
  'G#m': [[0, 4, 1], [1, 4, 1], [2, 4, 1], [3, 6, 4], [4, 6, 3], [5, 4, 1]],
  'D#m': [[0, 6, 1], [1, 6, 1], [2, 7, 2], [3, 8, 4], [4, 8, 3], [5, 6, 1]],
  'Bbm': [[0, 1, 1], [1, 1, 1], [2, 2, 2], [3, 3, 4], [4, 3, 3], [5, 1, 1]],
};

// Chord relationships for each major key
// Format: { key: { I: 'chord', IV: 'chord', V: 'chord', vi: 'chord', ii: 'chord', iii: 'chord' } }
const KEY_RELATIONSHIPS: { [key: string]: { [degree: string]: string } } = {
  'C': { I: 'C', IV: 'F', V: 'G', vi: 'Am', ii: 'Dm', iii: 'Em' },
  'D': { I: 'D', IV: 'G', V: 'A', vi: 'Bm', ii: 'Em', iii: 'F#m' },
  'E': { I: 'E', IV: 'A', V: 'B', vi: 'C#m', ii: 'F#m', iii: 'G#m' },
  'F': { I: 'F', IV: 'Bb', V: 'C', vi: 'Dm', ii: 'Gm', iii: 'Am' },
  'G': { I: 'G', IV: 'C', V: 'D', vi: 'Em', ii: 'Am', iii: 'Bm' },
  'A': { I: 'A', IV: 'D', V: 'E', vi: 'F#m', ii: 'Bm', iii: 'C#m' },
  'B': { I: 'B', IV: 'E', V: 'F#', vi: 'G#m', ii: 'C#m', iii: 'D#m' },
};

// Color mapping for chord functions
const CHORD_COLORS: { [degree: string]: string } = {
  I: '#EF4444',      // Red - Root/Tonic
  IV: '#10B981',     // Green - Subdominant
  V: '#3B82F6',      // Blue - Dominant
  vi: '#F97316',     // Orange - Relative minor
  ii: '#EAB308',     // Yellow - Supertonic minor
  iii: '#06B6D4',    // Light Blue/Cyan - Mediant minor
};

export function ChordAllPage() {
  const { sendLEDData, isConnected } = useBLE();
  const [selectedKey, setSelectedKey] = useState<string>('C');
  const [activeLEDs, setActiveLEDs] = useState<LED[]>([]);
  const [currentChordIndex, setCurrentChordIndex] = useState<number>(0);
  const [showChord, setShowChord] = useState<boolean>(true);

  const majorKeys = ['C', 'D', 'E', 'F', 'G', 'A', 'B'];
  const chordOrder = ['I', 'IV', 'V', 'vi', 'ii', 'iii']; // Order to cycle through chords

  // Empty click handler since this page doesn't support manual LED toggling
  const handleLEDClick = (fret: number, string: number) => {
    // No-op for this page
  };

  // Reset to first chord when key changes
  useEffect(() => {
    setCurrentChordIndex(0);
    setShowChord(true);
  }, [selectedKey]);

  // Sequential chord animation - cycle through chords one at a time
  useEffect(() => {
    const relationships = KEY_RELATIONSHIPS[selectedKey];
    if (!relationships) return;

    // Timer for chord cycling: show chord for 1.5s, off for 0.5s
    const duration = showChord ? 1500 : 500;
    
    const timeout = setTimeout(() => {
      if (showChord) {
        // Turn off the current chord
        setShowChord(false);
      } else {
        // Turn on and move to next chord
        setCurrentChordIndex(prevIndex => (prevIndex + 1) % chordOrder.length);
        setShowChord(true);
      }
    }, duration);

    return () => clearTimeout(timeout);
  }, [selectedKey, showChord, currentChordIndex]);

  // Generate LEDs for the current chord being displayed
  useEffect(() => {
    const relationships = KEY_RELATIONSHIPS[selectedKey];
    if (!relationships || !showChord) {
      setActiveLEDs([]);
      return;
    }

    const currentDegree = chordOrder[currentChordIndex];
    const chordName = relationships[currentDegree];
    const color = CHORD_COLORS[currentDegree];
    
    if (!chordName) {
      setActiveLEDs([]);
      return;
    }

    const shape = CHORD_SHAPES[chordName];
    if (!shape) {
      setActiveLEDs([]);
      return;
    }

    const leds: LED[] = [];
    shape.forEach(([string, fret, finger]) => {
      // Skip open strings (fret 0) as they don't show on LED fretboard
      if (fret > 0) {
        leds.push({
          string,
          fret: fret - 1, // Adjust for 0-indexed fretboard
          color,
          label: currentDegree, // Show degree (I, IV, V, etc.)
        });
      }
    });

    setActiveLEDs(leds);
  }, [selectedKey, currentChordIndex, showChord]);

  // Send LED data when connected or LEDs change
  useEffect(() => {
    if (isConnected && activeLEDs.length > 0) {
      sendLEDData(activeLEDs);
    }
  }, [activeLEDs, isConnected, sendLEDData]);

  return (
    <div className="flex flex-col h-full">
      {/* Description */}
      <div className="bg-gray-950 border-b border-gray-800 px-1 py-0.5">
        <p className="text-gray-400 text-center text-[8px]">
          Sequential chord display - Each chord plays for 1.5s
        </p>
      </div>

      {/* Chord Legend */}
      <div className="bg-gray-900 px-1 py-1 border-b border-gray-800">
        <div className="text-white mb-0.5 text-[9px]">
          Key of {selectedKey} Major - {showChord ? 'Playing' : 'Switching'}...
        </div>
        <div className="grid grid-cols-2 sm:grid-cols-3 gap-0.5 text-[8px]">
          {selectedKey && KEY_RELATIONSHIPS[selectedKey] && (
            <>
              {chordOrder.map((degree) => {
                const chordName = KEY_RELATIONSHIPS[selectedKey][degree];
                const isActive = showChord && chordOrder[currentChordIndex] === degree;
                return (
                  <div 
                    key={degree} 
                    className={`flex items-center gap-1 transition-all ${
                      isActive ? 'scale-110 font-bold' : 'opacity-50'
                    }`}
                  >
                    <div 
                      className={`w-1.5 h-1.5 rounded-full flex-shrink-0 ${
                        isActive ? 'animate-pulse shadow-lg' : ''
                      }`} 
                      style={{ 
                        backgroundColor: CHORD_COLORS[degree],
                        boxShadow: isActive ? `0 0 6px ${CHORD_COLORS[degree]}` : 'none'
                      }} 
                    />
                    <span className="text-white truncate">{chordName} ({degree})</span>
                  </div>
                );
              })}
            </>
          )}
        </div>
      </div>

      {/* Fretboard */}
      <div className="flex-1 overflow-hidden bg-black">
        <AnimatedLEDFretboard activeLEDs={activeLEDs} onLEDClick={handleLEDClick} />
      </div>

      {/* Key Selector - Bottom */}
      <div className="bg-gray-950 border-t border-gray-800 px-4 py-3">
        <div className="text-gray-400 text-xs mb-2">Select Key</div>
        <div className="flex gap-2 justify-center">
          {majorKeys.map((key) => (
            <button
              key={key}
              onClick={() => setSelectedKey(key)}
              className={`px-4 py-3 rounded whitespace-nowrap transition-all text-5xl ${
                selectedKey === key
                  ? 'bg-green-500 text-black'
                  : 'bg-gray-800 text-white hover:bg-gray-700'
              }`}
            >
              {key}
            </button>
          ))}
        </div>
      </div>

      {/* BLE Status */}
      {!isConnected && (
        <div className="bg-yellow-900/50 px-4 py-2 text-yellow-200 text-sm text-center border-t border-yellow-800">
          ⚠️ Not connected to ESP32. Go to Settings to connect.
        </div>
      )}
    </div>
  );
}

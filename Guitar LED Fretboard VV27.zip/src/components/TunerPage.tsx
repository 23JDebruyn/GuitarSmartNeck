import { useState, useEffect, useRef } from 'react';
import { Mic, MicOff, Volume2 } from 'lucide-react';
import { useBLE } from './WiFiContext';

// Frequency detection accuracy window (cents)
const CENTS_RANGE = 50; // Show up to ±50 cents
const IN_TUNE_THRESHOLD = 5; // ±5 cents is considered "in tune"

export function TunerPage() {
  const { sendLEDData, clearLEDs, tuningConfig } = useBLE();
  const STANDARD_TUNING = tuningConfig; // Use tuning from settings
  const [isListening, setIsListening] = useState(false);
  const [frequency, setFrequency] = useState<number | null>(null);
  const [detectedNote, setDetectedNote] = useState<string | null>(null);
  const [cents, setCents] = useState<number>(0);
  const [closestString, setClosestString] = useState<number | null>(null);
  const [error, setError] = useState<string | null>(null);
  const [isFlashing, setIsFlashing] = useState(false);
  const [permissionStatus, setPermissionStatus] = useState<'unknown' | 'granted' | 'denied' | 'prompt'>('unknown');
  const [debugLogs, setDebugLogs] = useState<string[]>([]);
  const [showDebug, setShowDebug] = useState(false);

  // Debug logger
  const addDebugLog = (message: string) => {
    const timestamp = new Date().toLocaleTimeString();
    setDebugLogs(prev => [...prev.slice(-9), `[${timestamp}] ${message}`]);
    console.log(message);
  };

  const audioContextRef = useRef<AudioContext | null>(null);
  const analyserRef = useRef<AnalyserNode | null>(null);
  const micStreamRef = useRef<MediaStream | null>(null);
  const animationFrameRef = useRef<number | null>(null);
  const lastFlashTimeRef = useRef<number>(0);

  // Check microphone permission status on mount
  useEffect(() => {
    const checkPermission = async () => {
      try {
        // iOS Safari doesn't support Permissions API for microphone
        // We'll detect the browser and handle accordingly
        const isIOS = /iPad|iPhone|iPod/.test(navigator.userAgent);
        const isSafari = /^((?!chrome|android).)*safari/i.test(navigator.userAgent);
        
        if (isIOS || isSafari) {
          // For iOS/Safari, we can't check permission status beforehand
          // Set to 'prompt' so user knows to try clicking
          setPermissionStatus('prompt');
          addDebugLog('iOS/Safari detected - permission check not available');
        } else if (navigator.permissions && navigator.permissions.query) {
          // For Chrome/Firefox on desktop and Android
          const result = await navigator.permissions.query({ name: 'microphone' as PermissionName });
          setPermissionStatus(result.state);
          addDebugLog(`Permission status: ${result.state}`);
          
          // Listen for permission changes
          result.onchange = () => {
            setPermissionStatus(result.state);
            addDebugLog(`Permission changed to: ${result.state}`);
          };
        } else {
          setPermissionStatus('prompt');
          addDebugLog('Permission API not available');
        }
      } catch (err) {
        // Permission API not supported - default to prompt
        addDebugLog(`Permission API error: ${err}`);
        setPermissionStatus('prompt');
      }
    };
    
    checkPermission();
  }, []);

  // Convert frequency to note name and cents offset
  const frequencyToNote = (freq: number) => {
    const A4 = 440;
    const C0 = A4 * Math.pow(2, -4.75);
    const halfSteps = Math.round(12 * Math.log2(freq / C0));
    const noteNames = ['C', 'C#', 'D', 'D#', 'E', 'F', 'F#', 'G', 'G#', 'A', 'A#', 'B'];
    const noteName = noteNames[halfSteps % 12];
    const octave = Math.floor(halfSteps / 12);
    const targetFreq = C0 * Math.pow(2, halfSteps / 12);
    const centsOff = 1200 * Math.log2(freq / targetFreq);
    
    return {
      note: `${noteName}${octave}`,
      cents: centsOff,
    };
  };

  // Find the closest guitar string
  const findClosestString = (freq: number) => {
    let minDiff = Infinity;
    let closest = null;
    
    STANDARD_TUNING.forEach((tuning) => {
      const diff = Math.abs(freq - tuning.frequency);
      if (diff < minDiff) {
        minDiff = diff;
        closest = tuning.string;
      }
    });
    
    return closest;
  };

  // Calculate how many LEDs to light based on tuning accuracy
  const calculateLEDCount = (centsOff: number): number => {
    const absCents = Math.abs(centsOff);
    
    // Perfect tuning (±5 cents): all 24 LEDs
    if (absCents <= IN_TUNE_THRESHOLD) return 24;
    
    // Map cents to LED count (0-50 cents maps to 1-23 LEDs)
    // The closer to perfect, the more LEDs light up
    const normalizedCents = Math.min(absCents, CENTS_RANGE);
    const ledCount = Math.round(24 - (normalizedCents / CENTS_RANGE) * 23);
    return Math.max(1, Math.min(24, ledCount));
  };

  // Flash LEDs 3 times when in tune
  const flashInTuneLEDs = async (stringIndex: number) => {
    setIsFlashing(true);
    
    for (let i = 0; i < 3; i++) {
      // Turn all LEDs on
      const leds = [];
      for (let fret = 0; fret < 24; fret++) {
        leds.push({
          string: stringIndex,
          fret: fret,
          r: 0,
          g: 255,
          b: 0,
        });
      }
      sendLEDs(leds);
      
      await new Promise(resolve => setTimeout(resolve, 200));
      
      // Turn all LEDs off
      clearLEDs();
      
      await new Promise(resolve => setTimeout(resolve, 200));
    }
    
    setIsFlashing(false);
  };

  // Update LED display based on tuning
  const updateLEDDisplay = (stringNum: number | null, centsOff: number) => {
    if (!stringNum || isFlashing) return;
    
    const tuningInfo = STANDARD_TUNING.find(t => t.string === stringNum);
    if (!tuningInfo) return;
    
    const stringIndex = tuningInfo.stringIndex;
    const absCents = Math.abs(centsOff);
    
    // Check if in tune
    if (absCents <= IN_TUNE_THRESHOLD) {
      // Prevent multiple flashes in quick succession
      const now = Date.now();
      if (now - lastFlashTimeRef.current > 3000) {
        lastFlashTimeRef.current = now;
        flashInTuneLEDs(stringIndex);
      }
      return;
    }
    
    // Calculate how many LEDs to light
    const ledCount = calculateLEDCount(centsOff);
    
    // Determine color based on tuning status
    let r = 255, g = 0, b = 0; // Default: red (sharp)
    
    if (centsOff < 0) {
      // Flat - blue
      r = 0;
      g = 100;
      b = 255;
    } else if (centsOff > 0) {
      // Sharp - red
      r = 255;
      g = 0;
      b = 0;
    }
    
    // Create LED array (light from nut outward)
    const leds = [];
    for (let fret = 0; fret < ledCount; fret++) {
      leds.push({
        string: stringIndex,
        fret: fret,
        r: r,
        g: g,
        b: b,
      });
    }
    
    sendLEDs(leds);
  };

  // Autocorrelation algorithm for pitch detection
  const autoCorrelate = (buffer: Float32Array, sampleRate: number): number => {
    const SIZE = buffer.length;
    const MAX_SAMPLES = Math.floor(SIZE / 2);
    let bestOffset = -1;
    let bestCorrelation = 0;
    let rms = 0;
    
    // Calculate RMS (Root Mean Square) for noise gate
    for (let i = 0; i < SIZE; i++) {
      const val = buffer[i];
      rms += val * val;
    }
    rms = Math.sqrt(rms / SIZE);
    
    // Noise gate - if signal is too quiet, return -1
    if (rms < 0.01) return -1;
    
    // Find the best correlation
    let lastCorrelation = 1;
    for (let offset = 1; offset < MAX_SAMPLES; offset++) {
      let correlation = 0;
      
      for (let i = 0; i < MAX_SAMPLES; i++) {
        correlation += Math.abs(buffer[i] - buffer[i + offset]);
      }
      
      correlation = 1 - correlation / MAX_SAMPLES;
      
      if (correlation > 0.9 && correlation > lastCorrelation) {
        const foundGoodCorrelation = correlation > bestCorrelation;
        if (foundGoodCorrelation) {
          bestCorrelation = correlation;
          bestOffset = offset;
        }
      }
      lastCorrelation = correlation;
    }
    
    if (bestCorrelation > 0.01 && bestOffset !== -1) {
      return sampleRate / bestOffset;
    }
    return -1;
  };

  // Process audio and detect frequency
  const detectPitch = () => {
    if (!analyserRef.current || !audioContextRef.current) return;
    
    const analyser = analyserRef.current;
    const bufferLength = analyser.fftSize;
    const buffer = new Float32Array(bufferLength);
    analyser.getFloatTimeDomainData(buffer);
    
    const detectedFreq = autoCorrelate(buffer, audioContextRef.current.sampleRate);
    
    if (detectedFreq !== -1 && detectedFreq > 50 && detectedFreq < 1000) {
      setFrequency(detectedFreq);
      
      const noteInfo = frequencyToNote(detectedFreq);
      setDetectedNote(noteInfo.note);
      setCents(noteInfo.cents);
      
      const stringNum = findClosestString(detectedFreq);
      setClosestString(stringNum);
      
      // Update LED display
      updateLEDDisplay(stringNum, noteInfo.cents);
    } else {
      setFrequency(null);
      setDetectedNote(null);
      setCents(0);
      setClosestString(null);
      
      // Clear LEDs when no signal
      if (!isFlashing) {
        clearLEDs();
      }
    }
    
    animationFrameRef.current = requestAnimationFrame(detectPitch);
  };

  // Start listening
  const startListening = async () => {
    try {
      setError(null);
      addDebugLog('Starting microphone...');
      
      // Check if MediaDevices API is available
      if (!navigator.mediaDevices || !navigator.mediaDevices.getUserMedia) {
        const errorMsg = 'Microphone API not available. Please use HTTPS or localhost.';
        addDebugLog(`ERROR: ${errorMsg}`);
        setError(errorMsg);
        return;
      }
      
      // Check if we're on HTTPS or localhost
      const isSecureContext = window.isSecureContext;
      addDebugLog(`Secure context: ${isSecureContext}`);
      addDebugLog(`Current URL: ${window.location.href}`);
      
      if (!isSecureContext) {
        const errorMsg = 'Microphone requires HTTPS. Please access via https:// or use localhost.';
        addDebugLog(`ERROR: ${errorMsg}`);
        setError(errorMsg);
        return;
      }
      
      addDebugLog('Requesting microphone access...');
      
      // Request microphone access with iOS-compatible constraints
      const constraints = {
        audio: {
          echoCancellation: false,
          autoGainControl: false,
          noiseSuppression: false,
          // Add iOS-specific settings
          sampleRate: 44100,
        } 
      };
      
      addDebugLog('Using constraints: ' + JSON.stringify(constraints));
      const stream = await navigator.mediaDevices.getUserMedia(constraints);
      addDebugLog(`Microphone granted! Tracks: ${stream.getTracks().length}`);
      
      micStreamRef.current = stream;
      
      // Create audio context (iOS requires user gesture)
      const AudioContextClass = window.AudioContext || (window as any).webkitAudioContext;
      const audioContext = new AudioContextClass();
      addDebugLog(`AudioContext created, state: ${audioContext.state}`);
      
      // iOS Safari requires resuming the audio context
      if (audioContext.state === 'suspended') {
        addDebugLog('AudioContext suspended, resuming...');
        await audioContext.resume();
        addDebugLog(`AudioContext resumed, state: ${audioContext.state}`);
      }
      
      audioContextRef.current = audioContext;
      
      // Create analyser
      const analyser = audioContext.createAnalyser();
      analyser.fftSize = 4096;
      analyser.smoothingTimeConstant = 0.8;
      analyserRef.current = analyser;
      addDebugLog('Analyser created');
      
      // Connect microphone to analyser
      const source = audioContext.createMediaStreamSource(stream);
      source.connect(analyser);
      addDebugLog('Audio pipeline connected successfully!');
      
      // Update permission status on success
      setPermissionStatus('granted');
      setIsListening(true);
      addDebugLog('Starting pitch detection...');
      detectPitch();
    } catch (err: any) {
      addDebugLog(`ERROR: ${err.name} - ${err.message}`);
      
      // Provide specific error messages
      if (err.name === 'NotAllowedError' || err.name === 'PermissionDeniedError') {
        setPermissionStatus('denied');
        addDebugLog('Permission DENIED by user');
        setShowDebug(true); // Auto-show debug console on error
        setError('Microphone access denied. Please allow microphone permissions in your browser settings.');
      } else if (err.name === 'NotFoundError') {
        setError('No microphone found. Please connect a microphone and try again.');
      } else if (err.name === 'NotReadableError') {
        setError('Microphone is being used by another application.');
      } else {
        setError(`Unable to access microphone: ${err.message || 'Unknown error'}`);
      }
    }
  };

  // Stop listening
  const stopListening = () => {
    if (animationFrameRef.current) {
      cancelAnimationFrame(animationFrameRef.current);
    }
    
    if (micStreamRef.current) {
      micStreamRef.current.getTracks().forEach(track => track.stop());
      micStreamRef.current = null;
    }
    
    if (audioContextRef.current) {
      audioContextRef.current.close();
      audioContextRef.current = null;
    }
    
    analyserRef.current = null;
    setIsListening(false);
    setFrequency(null);
    setDetectedNote(null);
    setCents(0);
    setClosestString(null);
    
    // Clear LEDs when stopping
    clearLEDs();
  };

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      stopListening();
    };
  }, []);

  // Get tuning status
  const getTuningStatus = () => {
    if (!frequency) return 'silent';
    if (Math.abs(cents) < IN_TUNE_THRESHOLD) return 'in-tune';
    if (cents > 0) return 'sharp';
    return 'flat';
  };

  const tuningStatus = getTuningStatus();

  // Calculate bar position (-50 to +50 cents maps to 0% to 100%)
  const getBarPosition = () => {
    if (!frequency) return 50;
    const clampedCents = Math.max(-CENTS_RANGE, Math.min(CENTS_RANGE, cents));
    return ((clampedCents + CENTS_RANGE) / (CENTS_RANGE * 2)) * 100;
  };

  // Calculate LED count for visual display
  const visualLEDCount = frequency ? calculateLEDCount(cents) : 0;

  return (
    <div className="h-full bg-black overflow-auto p-4">
      <div className="w-full max-w-6xl mx-auto space-y-6">
        {/* Title */}
        <div className="text-center mb-4">
          <h2 className="text-3xl mb-2 text-white">Guitar Tuner</h2>
          <p className="text-gray-400">Play a string to tune your guitar</p>
          
          {/* Debug Toggle Button */}
          <button
            onClick={() => setShowDebug(!showDebug)}
            className="mt-2 text-xs text-gray-500 hover:text-gray-300 underline"
          >
            {showDebug ? 'Hide' : 'Show'} Debug Info
          </button>
        </div>

        {/* Debug Console */}
        {showDebug && (
          <div className="bg-gray-950 border border-gray-700 rounded-lg p-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-sm text-gray-400">Debug Console</h3>
              <button
                onClick={() => setDebugLogs([])}
                className="text-xs text-red-400 hover:text-red-300"
              >
                Clear
              </button>
            </div>
            
            {/* System Info */}
            <div className="bg-gray-900 rounded p-2 mb-2 text-xs text-gray-300 space-y-1">
              <p><strong>Browser:</strong> {navigator.userAgent.includes('Safari') && !navigator.userAgent.includes('Chrome') ? 'Safari' : navigator.userAgent.includes('Chrome') ? 'Chrome' : 'Other'}</p>
              <p><strong>Device:</strong> {/iPad|iPhone|iPod/.test(navigator.userAgent) ? 'iOS' : /Android/.test(navigator.userAgent) ? 'Android' : 'Desktop'}</p>
              <p><strong>Protocol:</strong> <span className={window.location.protocol === 'https:' ? 'text-green-400' : 'text-red-400'}>{window.location.protocol}</span></p>
              <p><strong>Secure Context:</strong> <span className={window.isSecureContext ? 'text-green-400' : 'text-red-400'}>{window.isSecureContext ? 'Yes ✅' : 'No ❌'}</span></p>
              <p><strong>Permission:</strong> <span className={
                permissionStatus === 'granted' ? 'text-green-400' : 
                permissionStatus === 'denied' ? 'text-red-400' : 
                'text-yellow-400'
              }>{permissionStatus}</span></p>
            </div>
            
            <div className="bg-black rounded p-2 max-h-40 overflow-y-auto">
              {debugLogs.length === 0 ? (
                <p className="text-xs text-gray-600">No logs yet...</p>
              ) : (
                debugLogs.map((log, i) => (
                  <p key={i} className="text-xs text-green-400 font-mono mb-1">{log}</p>
                ))
              )}
            </div>
          </div>
        )}

        {/* HTTPS Warning Banner */}
        {!window.location.protocol.includes('https') && (
          <div className="bg-orange-900/50 border-2 border-orange-500 rounded-lg p-6 text-center mb-4">
            <div className="text-4xl mb-3">⚠️</div>
            <h3 className="text-2xl text-orange-300 mb-3">HTTPS Required!</h3>
            <p className="text-orange-200 mb-2 text-lg">Microphone access requires HTTPS (secure connection)</p>
            <div className="bg-orange-950/70 rounded-lg p-4 mt-4">
              <p className="text-sm text-orange-100 mb-2">Current URL: <span className="text-red-300 break-all">{window.location.href}</span></p>
              <p className="text-sm text-orange-100">Change <strong>http://</strong> to <strong>https://</strong> in the address bar</p>
            </div>
          </div>
        )}

        {/* Permission Status Banner */}
        {!isListening && permissionStatus === 'denied' && (
          <div className="bg-red-900/50 border-2 border-red-500 rounded-lg p-6 text-center">
            <div className="text-4xl mb-3">🔴</div>
            <h3 className="text-2xl text-red-300 mb-3 animate-pulse">Microphone Access BLOCKED</h3>
            <p className="text-red-200 mb-4 text-lg">The tuner cannot work without microphone access</p>
            
            <div className="flex flex-col gap-3 items-center mb-6">
              <button
                onClick={() => window.location.reload()}
                className="bg-yellow-600 hover:bg-yellow-700 text-white px-8 py-3 rounded-full text-lg transition-all shadow-lg"
              >
                🔄 Refresh Page After Fixing
              </button>
              <button
                onClick={() => setShowDebug(true)}
                className="bg-blue-600 hover:bg-blue-700 text-white px-6 py-2 rounded-full text-sm transition-all"
              >
                📊 Show Debug Info
              </button>
            </div>
            
            <div className="bg-red-950/70 rounded-lg p-4 text-left max-w-2xl mx-auto">
              {/* Show current URL for debugging */}
              <div className="mb-4 p-3 bg-black/50 rounded border border-red-700">
                <p className="text-xs text-gray-400 mb-1">Current URL:</p>
                <p className="text-xs text-yellow-300 break-all">{window.location.href}</p>
                <p className="text-xs text-gray-400 mt-2">
                  {window.location.protocol === 'https:' ? '✅ Using HTTPS' : '❌ NOT using HTTPS - Microphone needs HTTPS!'}
                </p>
              </div>
              
              <p className="text-yellow-300 text-sm mb-3"><strong>📱 How to Fix on iPhone/Safari:</strong></p>
              <ol className="list-decimal list-inside space-y-2 text-sm text-red-100 ml-2">
                <li>Open iPhone <strong>Settings</strong> app</li>
                <li>Scroll to <strong>Safari</strong></li>
                <li>Tap <strong>Microphone</strong></li>
                <li>Change from <strong>"Deny"</strong> to <strong>"Ask"</strong> or <strong>"Allow"</strong></li>
                <li>Return here and click the refresh button above</li>
              </ol>
              <p className="text-yellow-300 text-sm mt-4 mb-3"><strong>🌐 How to Fix on Chrome/Android:</strong></p>
              <ol className="list-decimal list-inside space-y-2 text-sm text-red-100 ml-2">
                <li>Tap the <strong>🔒 lock icon</strong> in address bar</li>
                <li>Tap <strong>"Permissions"</strong> or <strong>"Site settings"</strong></li>
                <li>Enable <strong>Microphone</strong></li>
                <li>Return here and click the refresh button above</li>
              </ol>
            </div>
          </div>
        )}

        {!isListening && (permissionStatus === 'prompt' || permissionStatus === 'unknown') && (
          <div className="bg-blue-900/50 border-2 border-blue-500 rounded-lg p-6 text-center">
            <div className="text-3xl mb-3">🎤</div>
            <h3 className="text-xl text-blue-300 mb-2">Microphone Permission Required</h3>
            <p className="text-blue-200 mb-3">Click "Start Tuner" below and <strong>ALLOW</strong> microphone access when prompted</p>
            
            {/* iOS/Safari specific instructions */}
            <div className="bg-blue-950/50 rounded-lg p-4 text-left max-w-xl mx-auto mt-4">
              <p className="text-yellow-300 text-sm mb-3"><strong>📱 BEFORE clicking Start Tuner, check this:</strong></p>
              <ol className="list-decimal list-inside space-y-2 text-sm text-blue-100 ml-2">
                <li className="mb-2">
                  <strong className="text-yellow-300">Check iPhone Settings:</strong>
                  <div className="ml-6 mt-1 text-xs text-blue-200">
                    Settings → Safari → Microphone → Must be <strong>"Ask"</strong> or <strong>"Allow"</strong> (NOT "Deny")
                  </div>
                </li>
                <li className="mb-2">
                  <strong className="text-yellow-300">Check URL:</strong>
                  <div className="ml-6 mt-1 text-xs text-blue-200">
                    URL must start with <strong>https://</strong> (not http://)
                  </div>
                  <div className="ml-6 mt-1 text-xs text-gray-400 break-all">
                    Current: {window.location.href}
                  </div>
                </li>
                <li>
                  <strong className="text-yellow-300">When popup appears:</strong> Tap <strong>"Allow"</strong>
                </li>
              </ol>
            </div>
          </div>
        )}

        {!isListening && permissionStatus === 'granted' && (
          <div className="bg-green-900/50 border-2 border-green-500 rounded-lg p-4 text-center">
            <div className="text-2xl mb-2">✅</div>
            <p className="text-green-300">Microphone ready! Click "Start Tuner" to begin</p>
          </div>
        )}

        {/* Microphone Control */}
        <div className="flex justify-center mb-4">
          <button
            onClick={isListening ? stopListening : startListening}
            className={`px-8 py-4 rounded-full flex items-center gap-3 transition-all ${
              isListening
                ? 'bg-red-600 hover:bg-red-700 shadow-lg'
                : 'bg-green-600 hover:bg-green-700'
            }`}
          >
            {isListening ? (
              <>
                <MicOff size={24} />
                <span className="text-xl">Stop Tuner</span>
              </>
            ) : (
              <>
                <Mic size={24} />
                <span className="text-xl">Start Tuner</span>
              </>
            )}
          </button>
        </div>

        {/* Error Message */}
        {error && (
          <div className="bg-red-900/50 border border-red-500 rounded-lg p-6 text-center">
            <p className="text-red-300 mb-4 text-lg">{error}</p>
            
            {error.includes('HTTPS') && (
              <div className="text-sm text-red-400 mt-4 space-y-3 text-left max-w-2xl mx-auto">
                <p className="text-center"><strong className="text-red-300 text-base">⚠️ HTTPS Required for Microphone Access</strong></p>
                <p><strong>iPhone/Safari:</strong> Use your computer's IP address with HTTPS</p>
                <p className="text-xs text-gray-400 ml-4">
                  Example: https://192.168.1.100:5173 (you may see a security warning - click "Advanced" then "Proceed")
                </p>
              </div>
            )}
            
            {error.includes('denied') && (
              <div className="text-sm text-left max-w-3xl mx-auto space-y-4 mt-4">
                <div className="bg-red-950/50 rounded-lg p-4 border border-red-600">
                  <p className="text-red-300 text-base mb-3 text-center"><strong>🔴 Microphone Permission Blocked</strong></p>
                  
                  <div className="space-y-4 text-red-200">
                    <div>
                      <p className="text-yellow-400 mb-2"><strong>📱 iPhone/Safari:</strong></p>
                      <ol className="list-decimal list-inside space-y-1 ml-2 text-sm">
                        <li>Open iPhone <strong>Settings</strong> app</li>
                        <li>Scroll down and tap <strong>Safari</strong></li>
                        <li>Under "Settings for Websites", tap <strong>Microphone</strong></li>
                        <li>Change to <strong>"Ask"</strong> or <strong>"Allow"</strong></li>
                        <li>Return here and refresh the page (pull down)</li>
                        <li>Tap "Start Tuner" and tap <strong>"Allow"</strong> when prompted</li>
                      </ol>
                    </div>
                    
                    <div className="border-t border-red-700 pt-4">
                      <p className="text-yellow-400 mb-2"><strong>🌐 Chrome/Android:</strong></p>
                      <ol className="list-decimal list-inside space-y-1 ml-2 text-sm">
                        <li>Tap the <strong>🔒 lock icon</strong> in the address bar</li>
                        <li>Tap <strong>"Site settings"</strong> or <strong>"Permissions"</strong></li>
                        <li>Find <strong>Microphone</strong> and change to <strong>"Allow"</strong></li>
                        <li>Refresh this page</li>
                        <li>Tap "Start Tuner" again</li>
                      </ol>
                    </div>
                    
                    <div className="border-t border-red-700 pt-4">
                      <p className="text-yellow-400 mb-2"><strong>💻 Desktop Chrome/Edge:</strong></p>
                      <ol className="list-decimal list-inside space-y-1 ml-2 text-sm">
                        <li>Click the <strong>camera/microphone icon</strong> (or 🔒) in address bar</li>
                        <li>Select <strong>"Always allow"</strong> for Microphone</li>
                        <li>Click <strong>"Done"</strong> and refresh the page</li>
                      </ol>
                    </div>
                    
                    <div className="bg-yellow-900/30 rounded p-3 mt-4 border border-yellow-700">
                      <p className="text-yellow-200 text-xs">
                        <strong>💡 Tip:</strong> If you previously clicked "Block" or "Don't Allow", you must manually enable it in settings. The browser won't ask again until you change the permission.
                      </p>
                    </div>
                  </div>
                </div>
              </div>
            )}
          </div>
        )}

        <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
          {/* Left Column: Visual Fretboard */}
          <div className="bg-gray-900 rounded-lg p-6">
            <h3 className="text-xl mb-4 text-center text-gray-300">Visual Fretboard</h3>
            
            {/* Fretboard Display (Perspective View: wide at bottom, narrow at top) */}
            <div className="relative h-[750px] bg-gradient-to-b from-gray-800 to-gray-900 rounded-lg overflow-hidden">
              {/* Fretboard background */}
              <svg width="100%" height="100%" viewBox="0 0 400 850" className="w-full h-full">
                <defs>
                  <linearGradient id="woodGrain" x1="0%" y1="0%" x2="0%" y2="100%">
                    <stop offset="0%" style={{ stopColor: '#3d2817', stopOpacity: 1 }} />
                    <stop offset="100%" style={{ stopColor: '#2d1810', stopOpacity: 1 }} />
                  </linearGradient>
                </defs>
                
                {/* Fretboard shape (trapezoid - wide at bottom/nut, narrow at top) */}
                {/* Bottom (nut) is at y=850, Top (24th fret) is at y=50 */}
                <polygon
                  points="100,50 300,50 360,850 40,850"
                  fill="url(#woodGrain)"
                  stroke="#1a1a1a"
                  strokeWidth="3"
                />
                
                {/* Fret markers */}
                {[3, 5, 7, 9, 12, 15, 17, 19, 21, 24].map((fret) => {
                  const progress = fret / 24;
                  const yPos = 850 - (progress * 800); // Reverse: fret 0 at bottom (850), fret 24 at top (50)
                  const leftX = 40 + (progress * 60);
                  const rightX = 360 - (progress * 60);
                  return (
                    <line
                      key={fret}
                      x1={leftX}
                      y1={yPos}
                      x2={rightX}
                      y2={yPos}
                      stroke="#555"
                      strokeWidth="2"
                      opacity="0.5"
                    />
                  );
                })}
                
                {/* Strings - Fixed spacing to match fretboard trapezoid */}
                {[0, 1, 2, 3, 4, 5].map((stringIdx) => {
                  // At top (24th fret, y=50): strings are closer together
                  const topWidth = 200; // Width at top
                  const topStart = 100; // Left edge at top
                  const topX = topStart + (topWidth / 5) * stringIdx;
                  
                  // At bottom (nut, y=850): strings are wider apart
                  const bottomWidth = 320; // Width at bottom
                  const bottomStart = 40; // Left edge at bottom
                  const bottomX = bottomStart + (bottomWidth / 5) * stringIdx;
                  
                  return (
                    <line
                      key={stringIdx}
                      x1={topX}
                      y1="50"
                      x2={bottomX}
                      y2="850"
                      stroke="#888"
                      strokeWidth={stringIdx === 5 || stringIdx === 4 ? "3" : "2"}
                      opacity="0.7"
                    />
                  );
                })}
              </svg>
              
              {/* LED indicators overlay */}
              {isListening && closestString && frequency && (
                <svg width="100%" height="100%" viewBox="0 0 400 850" className="absolute inset-0 w-full h-full">
                  {Array.from({ length: visualLEDCount }).map((_, fretIdx) => {
                    const tuningInfo = STANDARD_TUNING.find(t => t.string === closestString);
                    if (!tuningInfo) return null;
                    
                    const stringIdx = tuningInfo.stringIndex;
                    
                    // Calculate position along the string
                    const progress = (fretIdx + 0.5) / 24; // Center of fret space
                    
                    // String position at top (24th fret, y=50)
                    const topWidth = 200;
                    const topStart = 100;
                    const topX = topStart + (topWidth / 5) * stringIdx;
                    
                    // String position at bottom (nut, y=850)
                    const bottomWidth = 320;
                    const bottomStart = 40;
                    const bottomX = bottomStart + (bottomWidth / 5) * stringIdx;
                    
                    // Interpolate position along the string
                    // LEDs go from bottom (nut) upward as tuning improves
                    const yPos = 850 - (progress * 800); // Start from bottom (850) and go up to (50)
                    const xPos = bottomX + (topX - bottomX) * progress;
                    
                    // Color based on tuning status
                    let color = '#ef4444'; // red (sharp)
                    if (tuningStatus === 'in-tune') color = '#22c55e'; // green
                    else if (tuningStatus === 'flat') color = '#3b82f6'; // blue
                    
                    return (
                      <circle
                        key={fretIdx}
                        cx={xPos}
                        cy={yPos}
                        r="6"
                        fill={color}
                        className={tuningStatus === 'in-tune' && isFlashing ? 'animate-pulse' : ''}
                        style={{
                          filter: 'drop-shadow(0 0 8px currentColor)',
                        }}
                      />
                    );
                  })}
                </svg>
              )}
              
              {/* String labels at bottom (nut) */}
              <div className="absolute bottom-2 left-0 right-0 flex justify-between px-[40px]" style={{ width: '400px', maxWidth: '100%', margin: '0 auto' }}>
                {STANDARD_TUNING.map((tuning, idx) => {
                  // Position labels to match string positions at bottom
                  const bottomWidth = 320;
                  const position = (idx / 5) * 100; // Percentage position
                  
                  return (
                    <div
                      key={tuning.string}
                      className={`text-center transition-all ${
                        closestString === tuning.string && isListening
                          ? 'text-green-400 scale-125'
                          : 'text-gray-500'
                      }`}
                      style={{ width: '16.666%' }}
                    >
                      <div className="text-xl">{tuning.note}</div>
                      <div className="text-xs">{tuning.string}</div>
                      <div className="text-xs">{tuning.frequency.toFixed(0)}Hz</div>
                    </div>
                  );
                })}
              </div>
            </div>
            
            {/* LED Progress Indicator */}
            <div className="mt-4 text-center space-y-2">
              {isListening && frequency && (
                <>
                  <div className="text-sm text-gray-400">
                    LEDs lit: <span className={`${
                      tuningStatus === 'in-tune' ? 'text-green-400' :
                      tuningStatus === 'sharp' ? 'text-red-400' :
                      'text-blue-400'
                    }`}>{visualLEDCount}/24</span>
                  </div>
                  
                  {/* Frequency Reading */}
                  <div className="bg-gray-800 rounded-lg py-3 px-6 inline-block">
                    <div className="text-xs text-gray-500 mb-1">Current Frequency</div>
                    <div className="text-3xl text-white" style={{ fontVariant: 'tabular-nums' }}>
                      {frequency.toFixed(2)} Hz
                    </div>
                  </div>
                </>
              )}
            </div>
          </div>

          {/* Right Column: Tuning Info */}
          <div className="space-y-6">
            {/* Detected Note Display */}
            <div className="bg-gray-900 rounded-lg p-8 text-center">
              {isListening ? (
                frequency ? (
                  <>
                    <div className="mb-4">
                      <div className="text-8xl mb-2" style={{ fontVariant: 'tabular-nums' }}>
                        {detectedNote}
                      </div>
                      <div className="text-2xl text-gray-400">
                        {frequency.toFixed(2)} Hz
                      </div>
                    </div>
                    
                    {/* String Indicator */}
                    {closestString && (
                      <div className="text-xl text-green-400 mb-4">
                        String {closestString} ({STANDARD_TUNING.find(t => t.string === closestString)?.note})
                      </div>
                    )}

                    {/* Tuning Status */}
                    <div className={`text-2xl mb-4 ${
                      tuningStatus === 'in-tune' ? 'text-green-400' :
                      tuningStatus === 'sharp' ? 'text-red-400' :
                      tuningStatus === 'flat' ? 'text-blue-400' : 'text-gray-400'
                    }`}>
                      {tuningStatus === 'in-tune' && '✓ In Tune!'}
                      {tuningStatus === 'sharp' && `↑ ${cents.toFixed(0)} cents sharp`}
                      {tuningStatus === 'flat' && `↓ ${Math.abs(cents).toFixed(0)} cents flat`}
                    </div>

                    {/* Tuning Bar Graph */}
                    <div className="relative h-16 bg-gray-800 rounded-lg overflow-hidden">
                      {/* Center line */}
                      <div className="absolute left-1/2 top-0 bottom-0 w-1 bg-white z-10 transform -translate-x-1/2"></div>
                      
                      {/* Tuning indicator */}
                      <div
                        className={`absolute top-0 bottom-0 w-2 transition-all duration-100 ${
                          tuningStatus === 'in-tune' ? 'bg-green-500' :
                          tuningStatus === 'sharp' ? 'bg-red-500' :
                          'bg-blue-500'
                        }`}
                        style={{
                          left: `${getBarPosition()}%`,
                          transform: 'translateX(-50%)',
                        }}
                      ></div>
                      
                      {/* Labels */}
                      <div className="absolute inset-0 flex items-center justify-between px-4 text-sm text-gray-500">
                        <span>♭ Flat</span>
                        <span>Sharp ♯</span>
                      </div>
                    </div>
                  </>
                ) : (
                  <div className="flex flex-col items-center gap-4 py-12">
                    <Volume2 size={48} className="text-gray-600 animate-pulse" />
                    <p className="text-xl text-gray-400">Play a note...</p>
                  </div>
                )
              ) : (
                <div className="py-12">
                  <Mic size={48} className="text-gray-600 mx-auto mb-4" />
                  <p className="text-xl text-gray-400">Click "Start Tuner" to begin</p>
                </div>
              )}
            </div>

            {/* Reference Tuning Table */}
            <div className="bg-gray-900 rounded-lg p-4">
              <h3 className="text-lg mb-3 text-center text-gray-300">Standard Tuning</h3>
              <div className="grid grid-cols-2 sm:grid-cols-3 gap-2">
                {STANDARD_TUNING.map((tuning) => (
                  <div
                    key={tuning.string}
                    className={`p-3 rounded-lg text-center transition-all ${
                      closestString === tuning.string && isListening
                        ? 'bg-green-600 shadow-lg'
                        : 'bg-gray-800'
                    }`}
                  >
                    <div className="text-xs text-gray-400 mb-1">String {tuning.string}</div>
                    <div className="text-5xl mb-1">{tuning.note}</div>
                    <div className="text-xs text-gray-500">{tuning.frequency.toFixed(2)} Hz</div>
                  </div>
                ))}
              </div>
            </div>

            {/* Instructions */}
            <div className="bg-gray-900 rounded-lg p-6 text-sm text-gray-400">
              <h3 className="text-lg mb-3 text-white">How to Use:</h3>
              <ol className="list-decimal list-inside space-y-2 ml-2">
                <li>Connect to your guitar's WiFi first</li>
                <li>Click "Start Tuner" and allow microphone</li>
                <li>Play one string at a time</li>
                <li>Watch LEDs light up as you get closer to pitch</li>
                <li>When perfectly tuned, all 24 LEDs flash green 3 times!</li>
                <li>Blue = flat (tune up), Red = sharp (tune down)</li>
              </ol>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

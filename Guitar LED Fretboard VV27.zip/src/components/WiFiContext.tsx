import React, { createContext, useContext, useState, useCallback, useEffect } from 'react';

interface LED {
  fret: number;
  string: number;
  color?: string;
  label?: string;
}

export interface TuningConfig {
  string: number;
  note: string;
  frequency: number;
  name: string;
  stringIndex: number;
}

interface WiFiContextType {
  isConnected: boolean;
  isConnecting: boolean;
  deviceName: string | null;
  connect: (customIP?: string) => Promise<void>;
  disconnect: () => void;
  sendLEDData: (data: LED[] | number[]) => Promise<void>;
  clearLEDs: () => Promise<void>;
  orientation: 'vertical' | 'horizontal';
  setOrientation: (orientation: 'vertical' | 'horizontal') => void;
  esp32IP: string;
  setEsp32IP: (ip: string) => void;
  brightness: number;
  setBrightness: (brightness: number) => void;
  sendBrightness: (brightness: number) => Promise<void>;
  tuningConfig: TuningConfig[];
  setTuningConfig: (tuning: TuningConfig[]) => void;
}

const WiFiContext = createContext<WiFiContextType | undefined>(undefined);

export function WiFiProvider({ children }: { children: React.ReactNode }) {
  const [isConnected, setIsConnected] = useState(false);
  const [isConnecting, setIsConnecting] = useState(false);
  const [deviceName, setDeviceName] = useState<string | null>(null);
  const [orientation, setOrientation] = useState<'vertical' | 'horizontal'>('horizontal');
  const [esp32IP, setEsp32IP] = useState<string>(() => {
    // Load saved IP from localStorage
    return localStorage.getItem('esp32IP') || '192.168.4.1';
  });
  const [brightness, setBrightnessState] = useState<number>(() => {
    // Load saved brightness from localStorage (default: 128, range: 0-255)
    const saved = localStorage.getItem('ledBrightness');
    return saved ? parseInt(saved) : 128;
  });
  const [hasTriedAutoConnect, setHasTriedAutoConnect] = useState(false);

  // Default standard tuning
  const DEFAULT_TUNING: TuningConfig[] = [
    { string: 6, note: 'E', frequency: 82.41, name: 'E2', stringIndex: 5 }, // String 6 = index 5 (low E)
    { string: 5, note: 'A', frequency: 110.00, name: 'A2', stringIndex: 4 },
    { string: 4, note: 'D', frequency: 146.83, name: 'D3', stringIndex: 3 },
    { string: 3, note: 'G', frequency: 196.00, name: 'G3', stringIndex: 2 },
    { string: 2, note: 'B', frequency: 246.94, name: 'B3', stringIndex: 1 },
    { string: 1, note: 'e', frequency: 329.63, name: 'E4', stringIndex: 0 }, // String 1 = index 0 (high E)
  ];

  const [tuningConfig, setTuningConfigState] = useState<TuningConfig[]>(() => {
    // Load saved tuning from localStorage
    const saved = localStorage.getItem('tuningConfig');
    return saved ? JSON.parse(saved) : DEFAULT_TUNING;
  });

  const setTuningConfig = (tuning: TuningConfig[]) => {
    setTuningConfigState(tuning);
    localStorage.setItem('tuningConfig', JSON.stringify(tuning));
  };

  const connect = useCallback(async (customIP?: string) => {
    try {
      setIsConnecting(true);

      // Use provided IP or prompt user
      let targetIP = customIP;
      if (!targetIP) {
        targetIP = prompt('Enter ESP32 IP address:', esp32IP) || undefined;
        if (!targetIP) {
          setIsConnecting(false);
          return;
        }
      }
      
      setEsp32IP(targetIP);
      // Save IP to localStorage
      localStorage.setItem('esp32IP', targetIP);

      // Test connection by sending a ping request
      const response = await fetch(`http://${targetIP}/ping`, {
        method: 'GET',
        mode: 'cors',
      });

      if (!response.ok) {
        throw new Error('Failed to connect to ESP32');
      }

      const data = await response.json();
      console.log('Connected to ESP32:', data);

      setDeviceName(data.device || 'GuitarSmartNeck');
      setIsConnected(true);
      // Save connection state
      localStorage.setItem('lastConnected', 'true');
      console.log('WiFi connection established successfully');
    } catch (error) {
      console.error('WiFi connection error:', error);
      alert(`Connection failed: ${error instanceof Error ? error.message : 'Unknown error'}\n\nMake sure:\n1. ESP32 is powered on\n2. You are connected to ESP32's WiFi network\n3. IP address is correct (default: 192.168.4.1)`);
      setIsConnected(false);
      setDeviceName(null);
      localStorage.removeItem('lastConnected');
    } finally {
      setIsConnecting(false);
    }
  }, [esp32IP]);

  const disconnect = useCallback(() => {
    setIsConnected(false);
    setDeviceName(null);
    localStorage.removeItem('lastConnected');
    console.log('Disconnected from WiFi device');
  }, []);

  const sendLEDData = useCallback(async (data: LED[] | number[]) => {
    if (!isConnected) {
      console.log('Not connected - LED data not sent');
      return;
    }

    try {
      let ledData: any[];

      // Check if data is array of LEDs or raw binary data
      if (data.length > 0 && typeof data[0] === 'object') {
        const leds = data as LED[];
        // Convert LED data to JSON format for ESP32
        ledData = leds.map(led => {
          // Convert hex color to RGB
          const color = led.color || '#60a5fa';
          const r = parseInt(color.slice(1, 3), 16);
          const g = parseInt(color.slice(3, 5), 16);
          const b = parseInt(color.slice(5, 7), 16);

          return {
            string: led.string,
            fret: led.fret,
            r,
            g,
            b
          };
        });
      } else {
        // Raw binary data - not typical for WiFi, but kept for compatibility
        console.warn('Raw binary data not supported over WiFi, skipping');
        return;
      }

      const response = await fetch(`http://${esp32IP}/led`, {
        method: 'POST',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ leds: ledData }),
      });

      if (!response.ok) {
        throw new Error('Failed to send LED data');
      }

      console.log('LED data sent to ESP32');
    } catch (error) {
      console.error('Error sending LED data:', error);
      // Auto-disconnect on communication error
      setIsConnected(false);
      setDeviceName(null);
    }
  }, [isConnected, esp32IP]);

  const clearLEDs = useCallback(async () => {
    if (!isConnected) {
      console.log('Not connected - clear command not sent');
      return;
    }

    try {
      const response = await fetch(`http://${esp32IP}/clear`, {
        method: 'POST',
        mode: 'cors',
      });

      if (!response.ok) {
        throw new Error('Failed to clear LEDs');
      }

      console.log('Clear command sent to ESP32');
    } catch (error) {
      console.error('Error clearing LEDs:', error);
      // Auto-disconnect on communication error
      setIsConnected(false);
      setDeviceName(null);
    }
  }, [isConnected, esp32IP]);

  const sendBrightness = useCallback(async (brightnessValue: number) => {
    if (!isConnected) {
      console.log('Not connected - brightness not sent');
      return;
    }

    try {
      const response = await fetch(`http://${esp32IP}/brightness`, {
        method: 'POST',
        mode: 'cors',
        headers: {
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ brightness: brightnessValue }),
      });

      if (!response.ok) {
        throw new Error('Failed to set brightness');
      }

      console.log('Brightness sent to ESP32:', brightnessValue);
    } catch (error) {
      console.error('Error setting brightness:', error);
      // Don't disconnect on brightness error, it's not critical
    }
  }, [isConnected, esp32IP]);

  const setBrightness = useCallback((brightnessValue: number) => {
    setBrightnessState(brightnessValue);
    localStorage.setItem('ledBrightness', brightnessValue.toString());
    // Send to ESP32 if connected
    sendBrightness(brightnessValue);
  }, [sendBrightness]);

  // Auto-connect on mount if enabled
  useEffect(() => {
    const autoConnect = localStorage.getItem('autoConnect') === 'true';
    const lastConnected = localStorage.getItem('lastConnected') === 'true';
    
    if (autoConnect && lastConnected && !hasTriedAutoConnect && !isConnected) {
      setHasTriedAutoConnect(true);
      console.log('Auto-connecting to ESP32...');
      // Use silent connect without prompt
      connect(esp32IP).catch(() => {
        console.log('Auto-connect failed');
      });
    }
  }, [hasTriedAutoConnect, isConnected, esp32IP, connect]);

  const value: WiFiContextType = {
    isConnected,
    isConnecting,
    deviceName,
    connect,
    disconnect,
    sendLEDData,
    clearLEDs,
    orientation,
    setOrientation,
    esp32IP,
    setEsp32IP,
    brightness,
    setBrightness,
    sendBrightness,
    tuningConfig,
    setTuningConfig,
  };

  return <WiFiContext.Provider value={value}>{children}</WiFiContext.Provider>;
}

export function useWiFi() {
  const context = useContext(WiFiContext);
  if (context === undefined) {
    throw new Error('useWiFi must be used within a WiFiProvider');
  }
  return context;
}

// Export as useBLE for backward compatibility
export const useBLE = useWiFi;

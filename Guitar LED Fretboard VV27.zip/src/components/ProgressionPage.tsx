import React, { useState } from 'react';
import { AnimatedLEDFretboard } from './AnimatedLEDFretboard';
import { useBLE } from './WiFiContext';

interface LED {
  fret: number;
  string: number;
  color?: string;
  label?: string;
}

// Chord voicings - reusing from ChordPage
// Format: [string index (0-5), fret number, finger number (1-4)]
const CHORD_VOICINGS: { [key: string]: number[][][] } = {
  'C': [
    [[0, 0, 0], [1, 1, 1], [2, 0, 0], [3, 2, 2], [4, 3, 3]], // Position 1 - Open C
    [[0, 3, 2], [1, 5, 4], [2, 5, 3], [3, 5, 1], [4, 3, 1]], // Position 2
    [[0, 8, 3], [1, 8, 2], [2, 9, 4], [3, 10, 1], [4, 8, 1]], // Position 3
    [[0, 12, 1], [1, 13, 2], [2, 14, 4], [3, 14, 3], [4, 12, 1]], // Position 4
    [[0, 15, 2], [1, 17, 4], [2, 17, 3], [3, 17, 1], [4, 15, 1]], // Position 5
    [[0, 20, 3], [1, 20, 2], [2, 21, 4], [3, 22, 1], [4, 20, 1]], // Position 6
  ],
  'D': [
    [[0, 2, 2], [1, 3, 3], [2, 2, 1], [3, 0, 0]], // Position 1
    [[0, 5, 3], [1, 7, 4], [2, 7, 2], [3, 7, 1], [4, 5, 1]], // Position 2
    [[0, 10, 2], [1, 10, 1], [2, 11, 3], [3, 12, 4], [4, 10, 1]], // Position 3
    [[0, 14, 2], [1, 15, 3], [2, 14, 1], [3, 12, 0]], // Position 4
    [[0, 17, 3], [1, 19, 4], [2, 19, 2], [3, 19, 1], [4, 17, 1]], // Position 5
    [[0, 22, 2], [1, 22, 1], [2, 23, 3], [3, 24, 4], [4, 22, 1]], // Position 6
  ],
  'E': [
    [[0, 0, 0], [1, 0, 0], [2, 1, 1], [3, 2, 3], [4, 2, 2], [5, 0, 0]], // Position 1
    [[0, 7, 2], [1, 9, 4], [2, 9, 3], [3, 9, 1], [4, 7, 1]], // Position 2
    [[0, 12, 1], [1, 12, 1], [2, 13, 2], [3, 14, 4], [4, 14, 3], [5, 12, 1]], // Position 3
    [[0, 16, 4], [1, 17, 1], [2, 16, 3], [3, 16, 2]], // Position 4
    [[0, 19, 2], [1, 21, 4], [2, 21, 3], [3, 21, 1], [4, 19, 1]], // Position 5
    [[0, 24, 1], [1, 24, 1], [2, 25, 2], [3, 26, 4], [4, 26, 3], [5, 24, 1]], // Position 6
  ],
  'F': [
    [[0, 1, 1], [1, 1, 1], [2, 2, 2], [3, 3, 4], [4, 3, 3], [5, 1, 1]], // Position 1
    [[0, 5, 4], [1, 6, 1], [2, 5, 3], [3, 5, 2]], // Position 2
    [[0, 8, 2], [1, 10, 4], [2, 10, 3], [3, 10, 1], [4, 8, 1]], // Position 3
    [[0, 13, 1], [1, 13, 1], [2, 14, 2], [3, 15, 4], [4, 15, 3], [5, 13, 1]], // Position 4
    [[0, 17, 4], [1, 18, 1], [2, 17, 3], [3, 17, 2]], // Position 5
    [[0, 20, 2], [1, 22, 4], [2, 22, 3], [3, 22, 1], [4, 20, 1]], // Position 6
  ],
  'G': [
    [[0, 3, 3], [1, 0, 0], [2, 0, 0], [3, 0, 0], [4, 2, 1], [5, 3, 4]], // Position 1
    [[0, 3, 1], [1, 3, 1], [2, 4, 2], [3, 5, 4], [4, 5, 3], [5, 3, 1]], // Position 2
    [[0, 10, 3], [1, 12, 4], [2, 12, 2], [3, 12, 1], [4, 10, 1]], // Position 3
    [[0, 15, 3], [1, 12, 0], [2, 12, 0], [3, 12, 0], [4, 14, 1], [5, 15, 4]], // Position 4
    [[0, 15, 1], [1, 15, 1], [2, 16, 2], [3, 17, 4], [4, 17, 3], [5, 15, 1]], // Position 5
    [[0, 22, 3], [1, 24, 4], [2, 24, 2], [3, 24, 1], [4, 22, 1]], // Position 6
  ],
  'A': [
    [[0, 0, 0], [1, 2, 3], [2, 2, 2], [3, 2, 1], [4, 0, 0]], // Position 1
    [[0, 5, 1], [1, 5, 1], [2, 6, 2], [3, 7, 4], [4, 7, 3], [5, 5, 1]], // Position 2
    [[0, 9, 4], [1, 10, 1], [2, 9, 3], [3, 9, 2]], // Position 3
    [[0, 12, 0], [1, 14, 3], [2, 14, 2], [3, 14, 1], [4, 12, 0]], // Position 4
    [[0, 17, 1], [1, 17, 1], [2, 18, 2], [3, 19, 4], [4, 19, 3], [5, 17, 1]], // Position 5
    [[0, 21, 4], [1, 22, 1], [2, 21, 3], [3, 21, 2]], // Position 6
  ],
  'B': [
    [[0, 2, 2], [1, 4, 4], [2, 4, 3], [3, 4, 1], [4, 2, 1]], // Position 1
    [[0, 7, 1], [1, 7, 1], [2, 8, 2], [3, 9, 4], [4, 9, 3], [5, 7, 1]], // Position 2
    [[0, 11, 4], [1, 12, 1], [2, 11, 3], [3, 11, 2]], // Position 3
    [[0, 14, 2], [1, 16, 4], [2, 16, 3], [3, 16, 1], [4, 14, 1]], // Position 4
    [[0, 19, 1], [1, 19, 1], [2, 20, 2], [3, 21, 4], [4, 21, 3], [5, 19, 1]], // Position 5
    [[0, 23, 4], [1, 24, 1], [2, 23, 3], [3, 23, 2]], // Position 6
  ],
  'Am': [
    [[0, 0, 0], [1, 1, 1], [2, 2, 3], [3, 2, 2], [4, 0, 0]], // Position 1
    [[0, 5, 1], [1, 5, 1], [2, 5, 1], [3, 7, 4], [4, 7, 3], [5, 5, 1]], // Position 2
    [[0, 8, 4], [1, 10, 2], [2, 10, 1], [3, 9, 3]], // Position 3
    [[0, 12, 0], [1, 13, 1], [2, 14, 3], [3, 14, 2], [4, 12, 0]], // Position 4
    [[0, 17, 1], [1, 17, 1], [2, 17, 1], [3, 19, 4], [4, 19, 3], [5, 17, 1]], // Position 5
    [[0, 20, 4], [1, 22, 2], [2, 22, 1], [3, 21, 3]], // Position 6
  ],
  'Em': [
    [[0, 0, 0], [1, 0, 0], [2, 0, 0], [3, 2, 2], [4, 2, 1], [5, 0, 0]], // Position 1
    [[0, 7, 2], [1, 8, 3], [2, 9, 4], [3, 9, 1], [4, 7, 1]], // Position 2
    [[0, 12, 1], [1, 12, 1], [2, 12, 1], [3, 14, 4], [4, 14, 3], [5, 12, 1]], // Position 3
    [[0, 15, 4], [1, 17, 2], [2, 17, 1], [3, 16, 3]], // Position 4
    [[0, 19, 2], [1, 20, 3], [2, 21, 4], [3, 21, 1], [4, 19, 1]], // Position 5
    [[0, 24, 1], [1, 24, 1], [2, 24, 1], [3, 26, 4], [4, 26, 3], [5, 24, 1]], // Position 6
  ],
  'Dm': [
    [[0, 1, 1], [1, 3, 3], [2, 2, 2], [3, 0, 0]], // Position 1
    [[0, 5, 3], [1, 6, 4], [2, 7, 1], [3, 7, 2], [4, 5, 1]], // Position 2
    [[0, 10, 2], [1, 10, 1], [2, 10, 1], [3, 12, 4], [4, 12, 3], [5, 10, 1]], // Position 3
    [[0, 13, 1], [1, 15, 3], [2, 14, 2], [3, 12, 0]], // Position 4
    [[0, 17, 3], [1, 18, 4], [2, 19, 1], [3, 19, 2], [4, 17, 1]], // Position 5
    [[0, 22, 2], [1, 22, 1], [2, 22, 1], [3, 24, 4], [4, 24, 3], [5, 22, 1]], // Position 6
  ],
};

// Common chord progressions
const PROGRESSIONS = [
  { name: 'I-V-vi-IV (Pop)', chords: ['C', 'G', 'Am', 'F'] },
  { name: 'I-IV-V (Blues)', chords: ['C', 'F', 'G'] },
  { name: 'ii-V-I (Jazz)', chords: ['Dm', 'G', 'C'] },
  { name: 'I-vi-IV-V (50s)', chords: ['C', 'Am', 'F', 'G'] },
  { name: 'I-IV-vi-V', chords: ['C', 'F', 'Am', 'G'] },
  { name: 'vi-IV-I-V (Sensitive)', chords: ['Am', 'F', 'C', 'G'] },
  { name: 'I-V-vi-iii-IV', chords: ['C', 'G', 'Am', 'Em', 'F'] },
  { name: 'I-iii-IV-V', chords: ['C', 'Em', 'F', 'G'] },
];

// Finger colors
const FINGER_COLORS = {
  1: '#ef4444', // Red - Finger 1
  2: '#22c55e', // Green - Finger 2
  3: '#3b82f6', // Blue - Finger 3
  4: '#f97316', // Orange - Finger 4
};

export function ProgressionPage() {
  const { sendLEDData } = useBLE();
  const [selectedProgression, setSelectedProgression] = useState<number>(0);
  const [currentChordIndex, setCurrentChordIndex] = useState<number>(0);
  const [selectedPosition, setSelectedPosition] = useState<number>(1);
  const [activeLEDs, setActiveLEDs] = useState<LED[]>([]);

  React.useEffect(() => {
    const progression = PROGRESSIONS[selectedProgression];
    if (progression) {
      const currentChord = progression.chords[currentChordIndex];
      displayChord(currentChord, selectedPosition);
    }
  }, [selectedProgression, currentChordIndex, selectedPosition]);

  const displayChord = (chord: string, position: number) => {
    const voicings = CHORD_VOICINGS[chord];
    if (!voicings || !voicings[position - 1]) {
      setActiveLEDs([]);
      return;
    }

    const voicing = voicings[position - 1];
    const leds: LED[] = voicing.map(([stringIndex, fret, finger]) => ({
      fret,
      string: stringIndex,
      color: FINGER_COLORS[finger as keyof typeof FINGER_COLORS] || '#60a5fa',
      label: finger.toString(),
    }));

    setActiveLEDs(leds);
    
    // Send to ESP32 via BLE
    sendLEDData(leds);
  };

  const handleLEDClick = (fret: number, string: number) => {
    console.log(`Clicked: String ${string}, Fret ${fret}`);
  };

  const currentProgression = PROGRESSIONS[selectedProgression];
  const currentChord = currentProgression.chords[currentChordIndex];
  const availablePositions = CHORD_VOICINGS[currentChord]?.length || 0;

  return (
    <div className="flex flex-col h-full bg-black">
      {/* Fretboard Display */}
      <div className="flex-1 overflow-hidden">
        <AnimatedLEDFretboard activeLEDs={activeLEDs} onLEDClick={handleLEDClick} />
      </div>

      {/* Position Selector */}
      <div className="p-2 bg-gray-950">
        <div className="flex gap-1 mb-2 justify-center">
          {[1, 2, 3, 4, 5, 6].map((pos) => (
            <button
              key={pos}
              onClick={() => setSelectedPosition(pos)}
              disabled={pos > availablePositions}
              className={`w-5 h-5 rounded transition-colors flex items-center justify-center text-xl ${
                selectedPosition === pos
                  ? 'bg-green-600 text-white'
                  : pos <= availablePositions
                  ? 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                  : 'bg-gray-900 text-gray-600 cursor-not-allowed'
              }`}
            >
              {pos}
            </button>
          ))}
        </div>

        {/* Current Progression Display */}
        <div className="mb-1">
          <h3 className="text-gray-400 text-[10px] mb-1 text-center">
            {currentProgression.name}
          </h3>
          <div className="flex gap-1 justify-center mb-2">
            {currentProgression.chords.map((chord, index) => (
              <button
                key={index}
                onClick={() => setCurrentChordIndex(index)}
                className={`py-0.5 px-1.5 rounded transition-colors text-3xl min-w-[28px] flex items-center justify-center ${
                  currentChordIndex === index
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {chord}
              </button>
            ))}
          </div>
        </div>

        {/* Progression Selector */}
        <div className="mb-1">
          <div className="flex flex-wrap gap-1 justify-center max-w-4xl mx-auto">
            {PROGRESSIONS.map((progression, index) => (
              <button
                key={index}
                onClick={() => {
                  setSelectedProgression(index);
                  setCurrentChordIndex(0);
                  setSelectedPosition(1);
                }}
                className={`py-0.5 px-2 rounded transition-colors text-[10px] min-w-[60px] flex items-center justify-center ${
                  selectedProgression === index
                    ? 'bg-green-600 text-white'
                    : 'bg-gray-800 text-gray-300 hover:bg-gray-700'
                }`}
              >
                {progression.name}
              </button>
            ))}
          </div>
        </div>

        {/* Finger Legend */}
        <div className="flex gap-2 justify-center text-xs">
          {Object.entries(FINGER_COLORS).map(([finger, color]) => (
            <div key={finger} className="flex items-center gap-0.5">
              <div
                className="w-2 h-2 rounded-full"
                style={{ backgroundColor: color, boxShadow: `0 0 4px ${color}` }}
              />
              <span className="text-gray-400 text-[10px]">F{finger}</span>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

import React from 'react';
import { useBLE } from './WiFiContext';
import { Wifi, WifiOff, Settings, Home } from 'lucide-react';

interface TopNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

export function TopNav({ activeTab, onTabChange }: TopNavProps) {
  const tabs = ['Home', 'Chords', 'ChordAll', 'Custom', 'Progression', 'Pentatonic', 'Arpeggio', 'Tuner', 'Standard', 'Settings'];
  const { isConnected, isConnecting, deviceName, connect, disconnect } = useBLE();

  const handleBLEClick = () => {
    if (isConnected) {
      disconnect();
    } else {
      connect();
    }
  };

  return (
    <div className="bg-black border-b border-gray-800">
      <div className="flex gap-2 p-2 items-center">
        {/* WiFi Connect Button */}
        <button
          onClick={handleBLEClick}
          disabled={isConnecting}
          className={`px-4 py-2 rounded transition-colors whitespace-nowrap flex items-center gap-2 ${
            isConnected
              ? 'bg-green-600 text-white shadow-lg'
              : isConnecting
              ? 'bg-yellow-600 text-white'
              : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
          }`}
          style={isConnected ? { boxShadow: '0 0 20px rgba(34, 197, 94, 0.5)' } : undefined}
        >
          {isConnected ? (
            <Wifi size={16} />
          ) : (
            <WifiOff size={16} />
          )}
          <span>{isConnected ? (deviceName || 'Connected') : isConnecting ? 'Connecting...' : 'Connect WiFi'}</span>
        </button>

        {/* Tab Navigation */}
        <div className="flex gap-2 flex-1 overflow-x-auto">
          {tabs.filter(t => t !== 'Settings').map((tab) => (
            <button
              key={tab}
              onClick={() => onTabChange(tab)}
              className={`px-4 py-2 rounded transition-colors whitespace-nowrap flex items-center gap-1 ${
                activeTab === tab
                  ? 'bg-green-600 text-white'
                  : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
              }`}
            >
              {tab === 'Home' && <Home size={16} />}
              <span>{tab}</span>
            </button>
          ))}
        </div>

        {/* Settings Button */}
        <button
          onClick={() => onTabChange('Settings')}
          className={`px-4 py-2 rounded transition-colors whitespace-nowrap flex items-center gap-2 ${
            activeTab === 'Settings'
              ? 'bg-green-600 text-white'
              : 'bg-gray-800 text-gray-400 hover:bg-gray-700'
          }`}
        >
          <Settings size={16} />
          <span className="hidden sm:inline">Settings</span>
        </button>
      </div>
    </div>
  );
}

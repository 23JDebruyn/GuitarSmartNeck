import React from 'react';

export function CustomPage() {
  return (
    <div className="flex items-center justify-center h-full bg-black text-gray-400">
      <div className="text-center p-8">
        <h2 className="text-2xl mb-2">Custom</h2>
        <p>Create your custom chord patterns here</p>
      </div>
    </div>
  );
}

import { useState } from 'react';
import { useBLE, TuningConfig } from './WiFiContext';
import { Wifi, WifiOff, Loader2, Save, Sun, Music } from 'lucide-react';
import { Slider } from './ui/slider';

export function SettingsPage() {
  const { isConnected, isConnecting, deviceName, connect, disconnect, clearLEDs, esp32IP, setEsp32IP, brightness, setBrightness, tuningConfig, setTuningConfig } = useBLE();
  const [ipInput, setIpInput] = useState(esp32IP);
  const [autoConnect, setAutoConnect] = useState(() => {
    return localStorage.getItem('autoConnect') === 'true';
  });

  const handleWiFiAction = async () => {
    if (isConnected) {
      await clearLEDs();
      disconnect();
    } else {
      await connect();
    }
  };

  const handleSaveIP = () => {
    setEsp32IP(ipInput);
    localStorage.setItem('esp32IP', ipInput);
    alert('IP address saved!');
  };

  const handleAutoConnectToggle = () => {
    const newValue = !autoConnect;
    setAutoConnect(newValue);
    localStorage.setItem('autoConnect', newValue.toString());
  };

  const handleConnectToIP = async () => {
    await connect(ipInput);
  };

  const handleTuningChange = (stringIndex: number, field: 'note' | 'frequency', value: string) => {
    const newTuning = [...tuningConfig];
    if (field === 'note') {
      newTuning[stringIndex].note = value;
    } else if (field === 'frequency') {
      const freq = parseFloat(value);
      if (!isNaN(freq) && freq > 0) {
        newTuning[stringIndex].frequency = freq;
      }
    }
    setTuningConfig(newTuning);
  };

  const resetTuningToStandard = () => {
    const standardTuning: TuningConfig[] = [
      { string: 6, note: 'E', frequency: 82.41, name: 'E2', stringIndex: 5 },
      { string: 5, note: 'A', frequency: 110.00, name: 'A2', stringIndex: 4 },
      { string: 4, note: 'D', frequency: 146.83, name: 'D3', stringIndex: 3 },
      { string: 3, note: 'G', frequency: 196.00, name: 'G3', stringIndex: 2 },
      { string: 2, note: 'B', frequency: 246.94, name: 'B3', stringIndex: 1 },
      { string: 1, note: 'e', frequency: 329.63, name: 'E4', stringIndex: 0 },
    ];
    setTuningConfig(standardTuning);
  };

  const setDropDTuning = () => {
    const dropDTuning: TuningConfig[] = [
      { string: 6, note: 'D', frequency: 73.42, name: 'D2', stringIndex: 5 },
      { string: 5, note: 'A', frequency: 110.00, name: 'A2', stringIndex: 4 },
      { string: 4, note: 'D', frequency: 146.83, name: 'D3', stringIndex: 3 },
      { string: 3, note: 'G', frequency: 196.00, name: 'G3', stringIndex: 2 },
      { string: 2, note: 'B', frequency: 246.94, name: 'B3', stringIndex: 1 },
      { string: 1, note: 'e', frequency: 329.63, name: 'E4', stringIndex: 0 },
    ];
    setTuningConfig(dropDTuning);
  };

  const setHalfStepDown = () => {
    const halfStepDown: TuningConfig[] = [
      { string: 6, note: 'Eb', frequency: 77.78, name: 'Eb2', stringIndex: 5 },
      { string: 5, note: 'Ab', frequency: 103.83, name: 'Ab2', stringIndex: 4 },
      { string: 4, note: 'Db', frequency: 138.59, name: 'Db3', stringIndex: 3 },
      { string: 3, note: 'Gb', frequency: 185.00, name: 'Gb3', stringIndex: 2 },
      { string: 2, note: 'Bb', frequency: 233.08, name: 'Bb3', stringIndex: 1 },
      { string: 1, note: 'eb', frequency: 311.13, name: 'Eb4', stringIndex: 0 },
    ];
    setTuningConfig(halfStepDown);
  };

  const setOpenDTuning = () => {
    const openDTuning: TuningConfig[] = [
      { string: 6, note: 'D', frequency: 73.42, name: 'D2', stringIndex: 5 },
      { string: 5, note: 'A', frequency: 110.00, name: 'A2', stringIndex: 4 },
      { string: 4, note: 'D', frequency: 146.83, name: 'D3', stringIndex: 3 },
      { string: 3, note: 'F#', frequency: 185.00, name: 'F#3', stringIndex: 2 },
      { string: 2, note: 'A', frequency: 220.00, name: 'A3', stringIndex: 1 },
      { string: 1, note: 'd', frequency: 293.66, name: 'D4', stringIndex: 0 },
    ];
    setTuningConfig(openDTuning);
  };

  return (
    <div className="h-full bg-black overflow-auto p-4">
      <h2 className="text-2xl mb-6 text-white">Settings</h2>

      {/* WiFi Connection */}
      <div className="mb-6">
        <h3 className="text-lg mb-3 text-gray-300">WiFi Connection</h3>
        <div className="bg-gray-900 p-4 rounded-lg">
          <div className="flex items-center justify-between mb-3">
            <div className="flex items-center gap-2">
              {isConnected ? (
                <Wifi className="w-5 h-5 text-green-500" />
              ) : (
                <WifiOff className="w-5 h-5 text-gray-500" />
              )}
              <span className="text-gray-400">
                {deviceName || 'ESP32 GuitarSmartNeck'}
              </span>
            </div>
            <span className={isConnected ? 'text-green-500' : 'text-gray-500'}>
              {isConnected ? 'Connected' : 'Disconnected'}
            </span>
          </div>
          
          <button
            onClick={handleWiFiAction}
            disabled={isConnecting}
            className={`w-full py-3 rounded-lg flex items-center justify-center gap-2 transition-colors ${
              isConnected
                ? 'bg-red-600 hover:bg-red-700'
                : 'bg-green-600 hover:bg-green-700'
            } ${isConnecting ? 'opacity-50 cursor-not-allowed' : ''}`}
          >
            {isConnecting ? (
              <>
                <Loader2 className="w-4 h-4 animate-spin" />
                Connecting...
              </>
            ) : isConnected ? (
              'Disconnect'
            ) : (
              'Connect to ESP32'
            )}
          </button>
        </div>
      </div>

      {/* ESP32 IP Configuration */}
      <div className="mb-6">
        <h3 className="text-lg mb-3 text-gray-300">ESP32 IP Address</h3>
        <div className="bg-gray-900 p-4 rounded-lg">
          <div className="mb-3">
            <label className="block text-sm text-gray-400 mb-2">IP Address</label>
            <input
              type="text"
              value={ipInput}
              onChange={(e) => setIpInput(e.target.value)}
              placeholder="192.168.4.1"
              className="w-full px-4 py-3 bg-gray-800 text-white rounded-lg border border-gray-700 focus:border-green-500 focus:outline-none"
            />
          </div>
          
          <div className="grid grid-cols-2 gap-3">
            <button
              onClick={handleSaveIP}
              className="py-3 px-4 bg-blue-600 hover:bg-blue-700 rounded-lg flex items-center justify-center gap-2 transition-colors"
            >
              <Save size={16} />
              Save IP
            </button>
            <button
              onClick={handleConnectToIP}
              disabled={isConnecting}
              className="py-3 px-4 bg-green-600 hover:bg-green-700 rounded-lg flex items-center justify-center gap-2 transition-colors disabled:opacity-50"
            >
              {isConnecting ? <Loader2 className="w-4 h-4 animate-spin" /> : <Wifi size={16} />}
              Connect
            </button>
          </div>

          <div className="mt-3 text-xs text-gray-500">
            <p>Default ESP32 Access Point IP: 192.168.4.1</p>
          </div>
        </div>
      </div>

      {/* LED Brightness */}
      <div className="mb-6">
        <h3 className="text-lg mb-3 text-gray-300">LED Brightness</h3>
        <div className="bg-gray-900 p-4 rounded-lg">
          <div className="flex items-center gap-3 mb-3">
            <Sun className="w-5 h-5 text-yellow-500" />
            <div className="flex-1">
              <div className="flex items-center justify-between mb-2">
                <span className="text-white">Brightness</span>
                <span className="text-green-400 font-mono">{Math.round((brightness / 255) * 100)}%</span>
              </div>
              <Slider
                value={[brightness]}
                onValueChange={(value) => setBrightness(value[0])}
                min={0}
                max={255}
                step={1}
                className="w-full"
              />
            </div>
          </div>
          <p className="text-sm text-gray-400">
            Adjust the brightness of the LED fretboard (0-100%)
          </p>
        </div>
      </div>

      {/* Tuning Configuration */}
      <div className="mb-6">
        <h3 className="text-lg mb-3 text-gray-300 flex items-center gap-2">
          <Music className="w-5 h-5 text-blue-500" />
          Guitar Tuning
        </h3>
        <div className="bg-gray-900 p-4 rounded-lg">
          <p className="text-sm text-gray-400 mb-4">
            Adjust target frequencies for each string (used in Tuner page)
          </p>
          
          {/* String Configuration */}
          <div className="space-y-3 mb-4">
            {tuningConfig.map((config, index) => (
              <div key={config.string} className="flex items-center gap-3 bg-gray-800 p-3 rounded-lg">
                <div className="w-8 text-center">
                  <span className="text-gray-400 text-sm">#{config.string}</span>
                </div>
                <div className="flex-1 grid grid-cols-2 gap-3">
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Note</label>
                    <input
                      type="text"
                      value={config.note}
                      onChange={(e) => handleTuningChange(index, 'note', e.target.value)}
                      className="w-full px-3 py-2 bg-gray-700 text-white rounded border border-gray-600 focus:border-blue-500 focus:outline-none text-center"
                      maxLength={2}
                    />
                  </div>
                  <div>
                    <label className="block text-xs text-gray-500 mb-1">Frequency (Hz)</label>
                    <input
                      type="number"
                      value={config.frequency.toFixed(2)}
                      onChange={(e) => handleTuningChange(index, 'frequency', e.target.value)}
                      className="w-full px-3 py-2 bg-gray-700 text-white rounded border border-gray-600 focus:border-blue-500 focus:outline-none"
                      step="0.01"
                      min="20"
                      max="1000"
                    />
                  </div>
                </div>
              </div>
            ))}
          </div>

          {/* Preset Tunings */}
          <div className="space-y-2">
            <p className="text-xs text-gray-500 mb-2">Quick Presets:</p>
            <div className="grid grid-cols-2 gap-2">
              <button
                onClick={resetTuningToStandard}
                className="py-2 px-3 bg-blue-600 hover:bg-blue-700 rounded transition-colors text-xs"
              >
                Standard
              </button>
              <button
                onClick={setDropDTuning}
                className="py-2 px-3 bg-purple-600 hover:bg-purple-700 rounded transition-colors text-xs"
              >
                Drop D
              </button>
              <button
                onClick={setHalfStepDown}
                className="py-2 px-3 bg-orange-600 hover:bg-orange-700 rounded transition-colors text-xs"
              >
                Half Step ↓
              </button>
              <button
                onClick={setOpenDTuning}
                className="py-2 px-3 bg-teal-600 hover:bg-teal-700 rounded transition-colors text-xs"
              >
                Open D
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* Auto-Connect */}
      <div className="mb-6">
        <h3 className="text-lg mb-3 text-gray-300">Auto-Connect</h3>
        <div className="bg-gray-900 p-4 rounded-lg">
          <div className="flex items-center justify-between">
            <div>
              <p className="text-white">Auto-connect on startup</p>
              <p className="text-sm text-gray-400 mt-1">Automatically connect when app opens</p>
            </div>
            <label className="relative inline-flex items-center cursor-pointer">
              <input
                type="checkbox"
                checked={autoConnect}
                onChange={handleAutoConnectToggle}
                className="sr-only peer"
              />
              <div className="w-11 h-6 bg-gray-700 peer-focus:outline-none rounded-full peer peer-checked:after:translate-x-full peer-checked:after:border-white after:content-[''] after:absolute after:top-[2px] after:left-[2px] after:bg-white after:border-gray-300 after:border after:rounded-full after:h-5 after:w-5 after:transition-all peer-checked:bg-green-600"></div>
            </label>
          </div>
        </div>
      </div>

      {/* WiFi Setup Instructions */}
      <div className="mb-6">
        <h3 className="text-lg mb-3 text-gray-300">WiFi Setup</h3>
        <div className="bg-gray-900 p-4 rounded-lg text-sm text-gray-400 space-y-2">
          <p className="text-white mb-2">To connect to ESP32:</p>
          <ol className="list-decimal list-inside space-y-1 ml-2">
            <li>Connect phone to <span className="text-green-400 font-mono">GuitarSmartNeck</span> WiFi</li>
            <li>Password: <span className="text-green-400 font-mono">guitar123</span></li>
            <li>Enter IP address: <span className="text-green-400 font-mono">192.168.4.1</span></li>
            <li>Click Connect</li>
          </ol>
        </div>
      </div>

      {/* App Info */}
      <div className="mb-6">
        <h3 className="text-lg mb-3 text-gray-300">About</h3>
        <div className="bg-gray-900 p-4 rounded-lg space-y-2 text-sm text-gray-400">
          <div className="flex justify-between">
            <span>App Name</span>
            <span className="text-white">GuitarSmartNeck</span>
          </div>
          <div className="flex justify-between">
            <span>Version</span>
            <span className="text-white">2.0.0</span>
          </div>
          <div className="flex justify-between">
            <span>Device</span>
            <span className="text-white">ESP32</span>
          </div>
          <div className="flex justify-between">
            <span>Protocol</span>
            <span className="text-white">WiFi (HTTP)</span>
          </div>
          <div className="flex justify-between">
            <span>Current IP</span>
            <span className="text-green-400 font-mono">{esp32IP}</span>
          </div>
        </div>
      </div>

      {/* Install as App */}
      <div className="mb-6">
        <h3 className="text-lg mb-3 text-gray-300">Install App</h3>
        <div className="bg-gray-900 p-4 rounded-lg text-sm text-gray-400 space-y-2">
          <p className="text-white mb-2">Add to Home Screen:</p>
          <ul className="space-y-1 ml-2">
            <li><span className="text-green-400">iPhone/iPad:</span> Share button → Add to Home Screen</li>
            <li><span className="text-green-400">Android:</span> Menu (⋮) → Add to Home screen</li>
          </ul>
          <p className="text-xs text-gray-500 mt-3">
            This allows you to use the app like a native app without a browser!
          </p>
        </div>
      </div>
    </div>
  );
}

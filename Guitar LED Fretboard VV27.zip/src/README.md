# 🎸 GuitarSmartNeck - WiFi LED Fretboard App

Interactive guitar learning app with ESP32-controlled WS2812B LED fretboard (24 frets, 6 strings).

## 🚀 Quick Start

### 1. Install Dependencies
```bash
npm install
```

### 2. Start Development Server
```bash
npm run dev
```
Or double-click **START.bat** (Windows)

App runs at: `http://localhost:5173`

### 3. Build for Production
```bash
npm run build
```

### 4. Deploy to Vercel (for HTTPS - required for Tuner page)
```bash
npm install -g vercel
vercel --prod
```

---

## ✨ Features

- **🏠 Home Page** - Pattern Cycle button with 6 LED animations
- **🎵 Chord Page** - Display individual chords with LED patterns
- **🎸 ChordAll Page** - View all chords in a key
- **📊 Progression Page** - Chord progressions
- **🎹 Pentatonic Page** - 5 CAGED scale positions
- **🎼 Arpeggio Page** - 7 arpeggio types across 12 keys
- **🎤 Tuner Page** - Microphone-based guitar tuner (requires HTTPS)
- **📍 Standard Page** - Fret markers
- **✏️ Custom Page** - Create custom LED patterns
- **⚙️ Settings Page** - ESP32 IP config, auto-connect, LED brightness

### 🎨 Pattern Cycle (Home Page & Physical Button)
1. **Bar Fill** - Strings light up sequentially in white, red, blue, green
2. **Wave** - Wave animation across all frets
3. **Rainbow** - Each string in a different color
4. **Fret Indicators** - Navigate to Standard page
5. **Chords** - Navigate to Chord page
6. **Pentatonic** - Navigate to Pentatonic page

---

## 📱 App Features

- **PWA** - Installable Progressive Web App
- **WiFi/WebSocket** - Real-time ESP32 communication
- **Auto-connect** - Remembers ESP32 IP
- **Offline Ready** - Works after first load
- **Landscape Optimized** - Perfect for iPhone horizontal viewing

---

## 🔧 ESP32 Setup

1. Open **ESP32_WiFi_Fretboard_LED.ino** in Arduino IDE
2. Install libraries: **FastLED** + **ArduinoWebSockets** + **ArduinoJson**
3. Upload to ESP32
4. Check Serial Monitor (115200 baud):
   - Network: **GuitarSmartNeck**
   - Password: **guitar123**
   - IP: **192.168.4.1**

### 🔘 Optional: Add Physical Pattern Button
- Connect button between **GPIO 4** and **GND**
- Button press cycles through the 6 patterns
- Uses internal pull-up resistor (no external resistor needed)

---

## 📡 Connect Your Phone

1. Join WiFi: **GuitarSmartNeck** (password: guitar123)
2. Open app in browser
3. Go to **Settings** tab
4. Enter IP: **192.168.4.1**
5. Click **Save & Connect**
6. Enable **Auto-connect**

---

## 🎤 Using the Tuner

The Tuner page requires **HTTPS** to access the microphone.

**Solution:** Deploy to Vercel (free, 2 minutes):
```bash
vercel --prod
```

Then open the Vercel URL on your iPhone.

---

## 🛠️ Tech Stack

- **React** + **TypeScript** + **Tailwind CSS**
- **Vite** - Build tool
- **WebSocket** - ESP32 communication
- **Web Audio API** - Tuner functionality
- **Progressive Web App** - Installable

---

## 📦 Project Structure

```
/
├── src/
│   ├── App.tsx              # Main app (MUST have default export)
│   └── main.tsx             # Entry point
├── components/
│   ├── WiFiContext.tsx      # WebSocket/HTTP communication
│   ├── AnimatedLEDFretboard.tsx
│   ├── ChordPage.tsx
│   ├── ChordAllPage.tsx
│   ├── PentatonicPage.tsx
│   ├── ArpeggioPage.tsx
│   ├── TunerPage.tsx
│   ├── StandardPage.tsx
│   ├── CustomPage.tsx
│   ├── ProgressionPage.tsx
│   ├── SettingsPage.tsx
│   └── TopNav.tsx
├── public/
│   ├── manifest.json        # PWA config
│   └── guitar-icon.svg
├── ESP32_WiFi_Fretboard_LED.ino
└── START.bat               # Quick start script
```

---

## 🔥 Hardware

- **ESP32** (any variant)
- **WS2812B LED Strip** - 144 LEDs (6 strings × 24 frets)
- **5V 10A Power Supply** (for LEDs)
- **470Ω Resistor** (GPIO5 → Data In)
- **1000µF Capacitor** (across power supply)

**Wiring:**
- ESP32 GPIO 5 → 470Ω → LED Data In
- 5V Power → LED Strip 5V
- GND: ESP32 + LED Strip + Power Supply (common ground)

---

## 🚨 Troubleshooting

### Build errors?
The build is configured to skip TypeScript strict checking for deployment.

### Can't connect to ESP32?
- Check WiFi: Must be on **GuitarSmartNeck** network
- Check IP: Should be **192.168.4.1**
- Check Serial Monitor: Should show "WebSocket server started"

### Tuner not working?
- Needs HTTPS (deploy to Vercel)
- Grant microphone permission
- Use Safari on iPhone

---

## 📄 License

MIT

---

## 🎸 Happy Playing!

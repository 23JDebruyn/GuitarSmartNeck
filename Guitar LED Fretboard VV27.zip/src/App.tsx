import { useState, useEffect } from 'react';
import { WiFiProvider } from './components/WiFiContext';
import { TopNav } from './components/TopNav';
import { HomePage } from './components/HomePage';
import { ChordPage } from './components/ChordPage';
import { ChordAllPage } from './components/ChordAllPage';
import { CustomPage } from './components/CustomPage';
import { ProgressionPage } from './components/ProgressionPage';
import { PentatonicPage } from './components/PentatonicPage';
import { ArpeggioPage } from './components/ArpeggioPage';
import { TunerPage } from './components/TunerPage';
import { StandardPage } from './components/StandardPage';
import { SettingsPage } from './components/SettingsPage';
import './styles/globals.css';
// v1.2 - Added HomePage with Pattern Cycle button

export type PageType = 'Home' | 'Chords' | 'ChordAll' | 'Custom' | 'Progression' | 'Pentatonic' | 'Arpeggio' | 'Tuner' | 'Standard' | 'Settings';

function AppContent() {
  const [activeTab, setActiveTab] = useState<PageType>('Home');

  const renderPage = () => {
    switch (activeTab) {
      case 'Home':
        return <HomePage onNavigate={(page) => setActiveTab(page)} />;
      case 'Chords':
        return <ChordPage />;
      case 'ChordAll':
        return <ChordAllPage />;
      case 'Custom':
        return <CustomPage />;
      case 'Progression':
        return <ProgressionPage />;
      case 'Pentatonic':
        return <PentatonicPage />;
      case 'Arpeggio':
        return <ArpeggioPage />;
      case 'Tuner':
        return <TunerPage />;
      case 'Standard':
        return <StandardPage />;
      case 'Settings':
        return <SettingsPage />;
      default:
        return <HomePage onNavigate={(page) => setActiveTab(page)} />;
    }
  };

  return (
    <div className="h-screen flex flex-col bg-black text-white overflow-hidden">
      {/* Top Navigation Tabs */}
      <TopNav activeTab={activeTab} onTabChange={(tab) => setActiveTab(tab as PageType)} />

      {/* Main Content */}
      <div className="flex-1 overflow-hidden">
        {renderPage()}
      </div>
    </div>
  );
}

function App() {
  return (
    <WiFiProvider>
      <AppContent />
    </WiFiProvider>
  );
}

export default App;

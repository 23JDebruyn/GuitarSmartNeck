/*
 * GuitarSmartNeck - ESP32 WiFi LED Controller with HTTP & WebSocket
 * 
 * This sketch creates a WiFi Access Point with HTTP server and WebSocket server
 * to receive LED commands from the phone app and display them on WS2812B LED strips.
 * 
 * Hardware:
 * - ESP32 (any variant)
 * - WS2812B LED strips (144 LEDs for 24 frets x 6 strings)
 * - 5V Power Supply (recommended 10A for full brightness)
 * 
 * LED Strip Layout:
 * - 6 strings, 24 frets each = 144 LEDs total
 * - LEDs are arranged: String 0 (E high) - Frets 0-23, String 1 (B) - Frets 0-23, etc.
 */

#include <WiFi.h>
#include <WebServer.h>
#include <WebSocketsServer.h>
#include <FastLED.h>
#include <ArduinoJson.h>

// WiFi Access Point Settings
const char* ssid = "GuitarSmartNeck";
const char* password = "guitar123";  // Change this to your desired password

// LED Configuration
#define DATA_PIN        5         // GPIO pin connected to LED strip data line
#define NUM_LEDS        144       // 24 frets x 6 strings
#define NUM_STRINGS     6
#define NUM_FRETS       24
#define LED_TYPE        WS2812B
#define COLOR_ORDER     GRB
#define BRIGHTNESS      128       // 0-255, adjust for brightness

// Button Configuration
#define BUTTON_PIN      4         // GPIO pin for pattern cycle button
#define BUTTON_DEBOUNCE 50        // Debounce time in milliseconds

// WebSocket Configuration
#define WEBSOCKET_PORT  8080

// Globals
CRGB leds[NUM_LEDS];
WebSocketsServer webSocket = WebSocketsServer(WEBSOCKET_PORT);
WebServer server(80);  // HTTP server on port 80
uint8_t currentBrightness = BRIGHTNESS;  // Current brightness value
uint8_t currentPattern = 0;              // Current pattern index (0-5)
unsigned long lastButtonPress = 0;       // Last button press time for debouncing
bool lastButtonState = HIGH;             // Last button state (HIGH = not pressed with pull-up)

// Function to convert fret/string position to LED index
int getLEDIndex(uint8_t string, uint8_t fret) {
  if (string >= NUM_STRINGS || fret >= NUM_FRETS) return -1;
  return (string * NUM_FRETS) + fret;
}

// Pattern Functions
// Pattern 1: Bar fill with white, red, blue, green
void pattern1BarFill() {
  Serial.println("🎨 Pattern 1: Bar Fill");
  CRGB colors[] = {CRGB::White, CRGB::Red, CRGB::Blue, CRGB::Green};
  
  for (int c = 0; c < 4; c++) {
    // Light up each string sequentially
    for (int str = 0; str < NUM_STRINGS; str++) {
      FastLED.clear();
      // Light all strings up to current
      for (int s = 0; s <= str; s++) {
        for (int fret = 0; fret < NUM_FRETS; fret++) {
          int idx = getLEDIndex(s, fret);
          if (idx >= 0) leds[idx] = colors[c];
        }
      }
      FastLED.show();
      delay(150);
    }
    delay(500); // Hold all lit
  }
  FastLED.clear();
  FastLED.show();
}

// Pattern 2: Wave over all frets
void pattern2Wave() {
  Serial.println("🎨 Pattern 2: Wave");
  const int waveLength = 6;
  const int totalSteps = NUM_FRETS + waveLength;
  
  for (int step = 0; step < totalSteps; step++) {
    FastLED.clear();
    
    for (int str = 0; str < NUM_STRINGS; str++) {
      for (int offset = 0; offset < waveLength; offset++) {
        int fret = step - offset;
        if (fret >= 0 && fret < NUM_FRETS) {
          int idx = getLEDIndex(str, fret);
          if (idx >= 0) {
            uint8_t intensity = 255 * (waveLength - offset) / waveLength;
            leds[idx] = CRGB(0, intensity, 255 - intensity);
          }
        }
      }
    }
    
    FastLED.show();
    delay(50);
  }
  
  FastLED.clear();
  FastLED.show();
}

// Pattern 3: Rainbow - each string different color
void pattern3Rainbow() {
  Serial.println("🎨 Pattern 3: Rainbow Strings");
  CRGB stringColors[] = {
    CRGB::Red,           // String 0 (High E)
    CRGB(255, 165, 0),   // String 1 (B) - Orange
    CRGB::Yellow,        // String 2 (G)
    CRGB::Green,         // String 3 (D)
    CRGB::Blue,          // String 4 (A)
    CRGB(128, 0, 128)    // String 5 (Low E) - Purple
  };
  
  for (int str = 0; str < NUM_STRINGS; str++) {
    for (int fret = 0; fret < NUM_FRETS; fret++) {
      int idx = getLEDIndex(str, fret);
      if (idx >= 0) leds[idx] = stringColors[str];
    }
  }
  
  FastLED.show();
  delay(2000);
  FastLED.clear();
  FastLED.show();
}

// Execute pattern based on index
void executePattern(uint8_t patternIndex) {
  Serial.printf("⚡ Executing Pattern %d\n", patternIndex + 1);
  
  switch (patternIndex) {
    case 0:
      pattern1BarFill();
      break;
    case 1:
      pattern2Wave();
      break;
    case 2:
      pattern3Rainbow();
      break;
    case 3:
    case 4:
    case 5:
      // Patterns 4-6 are page navigations (only available in app)
      Serial.println("⚠️ Pattern navigation only available in app");
      // Just do a quick flash to indicate button press
      for (int i = 0; i < 2; i++) {
        fill_solid(leds, NUM_LEDS, CRGB::White);
        FastLED.show();
        delay(100);
        FastLED.clear();
        FastLED.show();
        delay(100);
      }
      break;
  }
}

// Check button and handle pattern cycle
void handleButton() {
  bool buttonState = digitalRead(BUTTON_PIN);
  unsigned long currentTime = millis();
  
  // Detect button press (LOW when pressed with pull-up resistor)
  if (buttonState == LOW && lastButtonState == HIGH) {
    // Check debounce
    if (currentTime - lastButtonPress > BUTTON_DEBOUNCE) {
      lastButtonPress = currentTime;
      
      // Cycle to next pattern
      currentPattern = (currentPattern + 1) % 6;
      Serial.printf("🔘 Button pressed! Pattern: %d\n", currentPattern);
      
      // Execute the pattern
      executePattern(currentPattern);
    }
  }
  
  lastButtonState = buttonState;
}

// HTTP Server Handlers
void handlePing() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  
  StaticJsonDocument<200> doc;
  doc["status"] = "ok";
  doc["device"] = "GuitarSmartNeck";
  doc["version"] = "2.0.0";
  
  String response;
  serializeJson(doc, response);
  server.send(200, "application/json", response);
  Serial.println("Ping received");
}

void handleLED() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200);
    return;
  }
  
  String body = server.arg("plain");
  StaticJsonDocument<4096> doc;
  DeserializationError error = deserializeJson(doc, body);
  
  if (error) {
    server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
    return;
  }
  
  // Clear all LEDs first
  FastLED.clear();
  
  // Process LED data
  JsonArray leds_array = doc["leds"];
  int ledCount = 0;
  for (JsonObject led_obj : leds_array) {
    int string = led_obj["string"];
    int fret = led_obj["fret"];
    int r = led_obj["r"];
    int g = led_obj["g"];
    int b = led_obj["b"];
    
    int ledIndex = getLEDIndex(string, fret);
    if (ledIndex >= 0 && ledIndex < NUM_LEDS) {
      leds[ledIndex] = CRGB(r, g, b);
      ledCount++;
    }
  }
  
  FastLED.show();
  Serial.printf("HTTP LED update: %d LEDs\n", ledCount);
  
  server.send(200, "application/json", "{\"status\":\"ok\"}");
}

void handleClear() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200);
    return;
  }
  
  FastLED.clear();
  FastLED.show();
  Serial.println("HTTP Clear LEDs");
  
  server.send(200, "application/json", "{\"status\":\"ok\"}");
}

void handleBrightness() {
  server.sendHeader("Access-Control-Allow-Origin", "*");
  server.sendHeader("Access-Control-Allow-Methods", "GET, POST, OPTIONS");
  server.sendHeader("Access-Control-Allow-Headers", "Content-Type");
  
  if (server.method() == HTTP_OPTIONS) {
    server.send(200);
    return;
  }
  
  String body = server.arg("plain");
  StaticJsonDocument<200> doc;
  DeserializationError error = deserializeJson(doc, body);
  
  if (error) {
    server.send(400, "application/json", "{\"error\":\"Invalid JSON\"}");
    return;
  }
  
  if (doc.containsKey("brightness")) {
    int brightness = doc["brightness"];
    if (brightness >= 0 && brightness <= 255) {
      currentBrightness = brightness;
      FastLED.setBrightness(currentBrightness);
      FastLED.show();
      Serial.printf("Brightness set to: %d\n", currentBrightness);
      server.send(200, "application/json", "{\"status\":\"ok\"}");
    } else {
      server.send(400, "application/json", "{\"error\":\"Brightness must be 0-255\"}");
    }
  } else {
    server.send(400, "application/json", "{\"error\":\"Missing brightness value\"}");
  }
}

void handleNotFound() {
  server.send(404, "text/plain", "Not Found");
}

// WebSocket Event Handler
void webSocketEvent(uint8_t num, WStype_t type, uint8_t * payload, size_t length) {
  switch(type) {
    case WStype_DISCONNECTED:
      Serial.printf("[%u] Disconnected!\n", num);
      break;
      
    case WStype_CONNECTED:
      {
        IPAddress ip = webSocket.remoteIP(num);
        Serial.printf("[%u] ✅ WebSocket connected from %d.%d.%d.%d\n", num, ip[0], ip[1], ip[2], ip[3]);
        webSocket.sendTXT(num, "Connected to GuitarSmartNeck!");
      }
      break;
      
    case WStype_TEXT:
      Serial.printf("[%u] Text message: %s\n", num, payload);
      break;
      
    case WStype_BIN:
      {
        if (length < 1) return;
        
        uint8_t numLeds = payload[0];
        Serial.printf("📡 Received: %d LEDs (packet size: %d bytes)\n", numLeds, length);
        
        // Clear all LEDs first
        FastLED.clear();
        
        // Process LED data (binary format)
        for (int i = 0; i < numLeds && i < 50; i++) {
          uint8_t offset = 1 + (i * 5);
          if (offset + 4 >= length) break;
          
          uint8_t string = payload[offset];
          uint8_t fret = payload[offset + 1];
          uint8_t r = payload[offset + 2];
          uint8_t g = payload[offset + 3];
          uint8_t b = payload[offset + 4];
          
          int ledIndex = getLEDIndex(string, fret);
          if (ledIndex >= 0 && ledIndex < NUM_LEDS) {
            leds[ledIndex] = CRGB(r, g, b);
            Serial.printf("  LED[%d]: String %d, Fret %d, RGB(%d,%d,%d)\n", 
                         ledIndex, string, fret, r, g, b);
          }
        }
        
        FastLED.show();
        Serial.println("✓ LEDs updated");
      }
      break;
      
    case WStype_ERROR:
      Serial.printf("[%u] WebSocket Error!\n", num);
      break;
      
    case WStype_FRAGMENT_TEXT_START:
    case WStype_FRAGMENT_BIN_START:
    case WStype_FRAGMENT:
    case WStype_FRAGMENT_FIN:
      break;
  }
}

void setup() {
  Serial.begin(115200);
  delay(1000);
  
  Serial.println("\n\n╔═══════════════════════════════════╗");
  Serial.println("║  GuitarSmartNeck WiFi LED         ║");
  Serial.println("║  HTTP + WebSocket Version         ║");
  Serial.println("║  with Button Pattern Cycle        ║");
  Serial.println("╚═══════════════════════════════════╝\n");
  
  // Initialize Button
  Serial.println("🔧 Initializing Button...");
  pinMode(BUTTON_PIN, INPUT_PULLUP);  // Internal pull-up resistor
  Serial.printf("   ✓ Button configured on GPIO %d\n\n", BUTTON_PIN);
  
  // Initialize LEDs
  Serial.println("🔧 Initializing LEDs...");
  FastLED.addLeds<LED_TYPE, DATA_PIN, COLOR_ORDER>(leds, NUM_LEDS);
  FastLED.setBrightness(BRIGHTNESS);
  FastLED.clear();
  FastLED.show();
  Serial.printf("   ✓ %d LEDs ready\n\n", NUM_LEDS);
  
  // Startup animation
  Serial.println("🎸 Running startup animation...");
  for (int i = 0; i < NUM_LEDS; i++) {
    leds[i] = CRGB::Blue;
    FastLED.show();
    delay(3);
  }
  FastLED.clear();
  FastLED.show();
  Serial.println("   ✓ Animation complete\n");
  
  // Initialize WiFi Access Point
  Serial.println("📡 Starting WiFi Access Point...");
  WiFi.mode(WIFI_AP);
  
  if (WiFi.softAP(ssid, password)) {
    delay(100);
    IPAddress IP = WiFi.softAPIP();
    
    Serial.println("   ✅ WiFi Started!");
    Serial.printf("   SSID: %s\n", ssid);
    Serial.printf("   Password: %s\n", password);
    Serial.printf("   IP Address: %s\n\n", IP.toString().c_str());
    
    // Start HTTP server
    Serial.println("🌐 Starting HTTP server...");
    server.on("/ping", HTTP_GET, handlePing);
    server.on("/led", HTTP_POST, handleLED);
    server.on("/led", HTTP_OPTIONS, handleLED);
    server.on("/clear", HTTP_POST, handleClear);
    server.on("/clear", HTTP_OPTIONS, handleClear);
    server.on("/brightness", HTTP_POST, handleBrightness);
    server.on("/brightness", HTTP_OPTIONS, handleBrightness);
    server.onNotFound(handleNotFound);
    server.begin();
    Serial.println("   ✅ HTTP server started on port 80\n");
    
    // Start WebSocket server
    Serial.println("🌐 Starting WebSocket server...");
    webSocket.begin();
    webSocket.onEvent(webSocketEvent);
    Serial.printf("   ✅ WebSocket server started on port %d\n\n", WEBSOCKET_PORT);
    
    Serial.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    Serial.println("📱 READY! Connection Instructions:");
    Serial.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━");
    Serial.println("1. On your phone/computer:");
    Serial.println("   • Connect to WiFi network:");
    Serial.printf("     Network: %s\n", ssid);
    Serial.printf("     Password: %s\n\n", password);
    Serial.println("2. Open the web app and click 'Connect WiFi'");
    Serial.println("   • Enter IP address (or use default):");
    Serial.printf("     IP Address: %s\n", IP.toString().c_str());
    Serial.println("   • Click 'Connect'");
    Serial.println("\n3. Start playing chords!");
    Serial.println("━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━\n");
    
    // Success indication - green flash
    for (int i = 0; i < 3; i++) {
      fill_solid(leds, NUM_LEDS, CRGB::Green);
      FastLED.show();
      delay(200);
      FastLED.clear();
      FastLED.show();
      delay(200);
    }
    
    Serial.println("✅ System ready! Waiting for connections...\n");
    
  } else {
    Serial.println("   ❌ ERROR: Failed to start WiFi!");
    // Error indication - red flash
    for (int i = 0; i < 5; i++) {
      fill_solid(leds, NUM_LEDS, CRGB::Red);
      FastLED.show();
      delay(200);
      FastLED.clear();
      FastLED.show();
      delay(200);
    }
  }
}

void loop() {
  // Handle HTTP requests
  server.handleClient();
  
  // Handle WebSocket connections
  webSocket.loop();
  
  // Handle button press for pattern cycle
  handleButton();
  
  // Optional: Heartbeat indicator on first LED (very dim)
  static unsigned long lastBlink = 0;
  if (millis() - lastBlink > 2000) {
    lastBlink = millis();
    leds[0] = CRGB(0, 5, 0);  // Very dim green
    FastLED.show();
    delay(50);
    leds[0] = CRGB::Black;
    FastLED.show();
  }
}

/*
 * ============================================
 * INSTALLATION INSTRUCTIONS
 * ============================================
 * 
 * 1. Install Arduino IDE (https://www.arduino.cc/en/software)
 * 
 * 2. Install ESP32 board support:
 *    • File > Preferences
 *    • Add to "Additional Board Manager URLs":
 *      https://raw.githubusercontent.com/espressif/arduino-esp32/gh-pages/package_esp32_index.json
 *    • Tools > Board > Boards Manager
 *    • Search "esp32" and install "esp32 by Espressif Systems"
 * 
 * 3. Install required libraries (Tools > Manage Libraries):
 *    • FastLED (by Daniel Garcia) - For LED control
 *    • WebSockets (by Markus Sattler) - For WebSocket communication
 *    • ArduinoJson (by Benoit Blanchon) - For JSON parsing
 * 
 * 4. Configure board settings:
 *    • Tools > Board > ESP32 Arduino > ESP32 Dev Module (or your board)
 *    • Tools > Upload Speed > 115200
 *    • Tools > Flash Frequency > 80MHz
 *    • Tools > Flash Size > 4MB
 *    • Tools > Port > Select your COM port
 * 
 * 5. Upload:
 *    • Connect ESP32 via USB
 *    • Click Upload button
 *    • Wait for "Done uploading"
 * 
 * 6. Test:
 *    • Open Serial Monitor (Tools > Serial Monitor)
 *    • Set baud rate to 115200
 *    • You should see startup messages
 * 
 * ============================================
 * WIRING
 * ============================================
 * 
 * LED Strip:
 *   • Data Pin -> ESP32 GPIO 5
 *   • 5V -> External 5V Power Supply (10A recommended)
 *   • GND -> ESP32 GND AND Power Supply GND (MUST share common ground!)
 * 
 * Pattern Cycle Button:
 *   • One side -> ESP32 GPIO 4
 *   • Other side -> GND
 *   • Note: Using internal pull-up resistor, button pulls LOW when pressed
 * 
 * ESP32:
 *   • Power via USB or external 5V
 *   • GND must be common with LED strip power supply
 * 
 * IMPORTANT: Do NOT power LED strips from ESP32 3.3V or 5V pins!
 *            Use external power supply for best results.
 * 
 * ============================================
 * TROUBLESHOOTING
 * ============================================
 * 
 * Problem: ESP32 won't upload
 * Solution: Hold BOOT button while clicking Upload
 * 
 * Problem: Can't see WiFi network
 * Solution: Check Serial Monitor for startup messages
 *           Press RESET button on ESP32
 * 
 * Problem: LEDs don't light up
 * Solution: Check wiring, especially GND connections
 *           Verify external power supply is ON
 *           Try lowering BRIGHTNESS value
 * 
 * Problem: Connection drops
 * Solution: Stay close to ESP32 (WiFi range issue)
 *           Reduce WiFi interference
 * 
 * Problem: Brightness control not working
 * Solution: Make sure ArduinoJson library is installed
 *           Check Serial Monitor for error messages
 * 
 * Problem: Button not responding
 * Solution: Check button wiring (GPIO 4 to GND when pressed)
 *           Check Serial Monitor for button press messages
 *           Verify button is momentary type (not latching)
 *           Try adjusting BUTTON_DEBOUNCE value
 * 
 * ============================================
 */

# 🚀 Deployment Guide

## Deploy to Vercel (HTTPS for Tuner)

The Tuner page requires HTTPS to access the microphone. Vercel provides free HTTPS deployment.

### Steps:

1. **Install Vercel CLI** (one time only)
```bash
npm install -g vercel
```

2. **Login to Vercel**
```bash
vercel login
```

3. **Deploy**
```bash
vercel --prod
```

4. **Done!**
You'll get a URL like: `https://your-app.vercel.app`

---

## Local Development

For local testing (without Tuner):

```bash
npm run dev
```

Access at: `http://localhost:5173`

---

## Build Locally

To test the build:

```bash
npm run build
```

Output will be in the `dist/` folder.

---

## Notes

- The build skips TypeScript strict checking (configured in package.json)
- Vercel automatically runs `npm run build` during deployment
- The app is configured as a Progressive Web App (PWA)
- All settings are stored in localStorage on the device

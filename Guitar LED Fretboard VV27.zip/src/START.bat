@echo off
title GuitarSmartNeck - Dev Server
color 0A
cls

echo ============================================
echo   GuitarSmartNeck - Starting Dev Server
echo ============================================
echo.

if not exist "node_modules" (
    echo Installing dependencies...
    call npm install
    echo.
)

echo Starting development server...
echo.
echo The app will open at: http://localhost:5173
echo.
echo Press Ctrl+C to stop the server
echo ============================================
echo.

npm run dev
